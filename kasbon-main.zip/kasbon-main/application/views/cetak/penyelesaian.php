<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <title>Kasbon | <?= $title ?></title>
    <base href="<?php echo base_url(); ?>" />
</head>
<style type="text/css">
    @page {
        margin-top: 1cm;
        margin-left: 1.5cm;
        margin-right: 1.5cm;
        margin-bottom: 0.1cm;
    }

    .nmr_srt {
        font-family: 'James Fajardo';
        font-weight: normal;
        font-size: 30px;
        vertical-align: middle;
        padding: 0 2px;
    }

    .name-head1 {
        font-size: 14pt;
        font-weight: bold;
        text-transform: uppercase;
        font-family: Arial, Helvetica, sans-serif;
        text-align: center;
        margin-bottom: -13px;
    }

    .name-head2 {
        font-size: 14pt;
        font-family: Arial, Helvetica, sans-serif;
        text-align: center;
        margin-bottom: -15px;
    }

    .name-head {
        font-size: 12pt;
        font-weight: bold;
        text-transform: uppercase;
        font-family: Arial, Helvetica, sans-serif;
        text-align: center;
        margin-bottom: -5px;
    }

    .alamat {
        font-size: 12pt;
        font-family: Arial, Helvetica, sans-serif;
        text-align: center;
        margin-top: -15px;
    }

    .alamat_1 {
        font-size: 11pt;
        margin-bottom: -28px;
        font-family: Arial, Helvetica, sans-serif;
        text-align: center;
    }

    .alamat2 {
        font-size: 9pt;
    }

    .isi {
        font-size: 13pt;
        margin-top: 10px;
        font-family: Arial, Helvetica, sans-serif;
        text-align: left;
        padding-left: 50px;
    }

    .isi_paragraf {
        font-size: 13pt;
        margin-top: 10px;
        font-family: Arial, Helvetica, sans-serif;
        text-align: left;
    }

    .ttd-kiri {
        font-size: 9pt;
        margin-left: 50px;
    }

    .ttd-kanan {
        font-size: 13pt;
        margin-right: 30px;
        text-align: center;
        font-family: Arial, Helvetica, sans-serif;
    }

    .cnt {
        margin-top:-15px;
    }

    .detail {
        font-size: 10pt;
        font-weight: bold;
        padding-top: -15px;
        padding-bottom: -12px;
    }

    body {
        font-family: Arial, Helvetica, sans-serif;
    }

    table.ttd{
        font-family: Arial, Helvetica, sans-serif, arial, sans-serif;
        font-size: 14px;
        color: #333333;
        border-width: none;
        border-collapse: collapse;
        width: 100%;
    }

    .table-left {
        float: left;
        width: 45%; /* Adjust width as needed */
        margin-right: 5%; /* Space between tables */
    }

    .table-right {
        float: right;
        width: 45%; /* Adjust width as needed */
        margin-left: 5%; /* Space between tables */
    }

    .clearfix::after {
        content: "";
        display: table;
        clear: both;
    }

    th {
        padding-bottom: 8px;
        padding-top: 8px;
        border-color: #666666;
        background-color: #dedede;
    }

    td {
        text-align: left;
        padding-left: 30px;
    }

    .border td {
        border: 1px solid black;
        text-align: left;
        padding: 8px;
    }

    .hr_satu {
        border-width: 4px;
        color: black;
        margin-top: 12px;
    }

    .hr_dua {
        border-width: 1px;
        color: black;
        margin-top: -15px;
    }

    .container {
        position: relative;
    }

    .topright {
        position: absolute;
        top: 0;
        right: 0;
        font-size: 18px;
        border-width: thin;
        padding: 5px;
    }

    .topright2 {
        position: absolute;
        top: 30px;
        right: 50px;
        font-size: 18px;
        border: 1px solid;
        padding: 5px;
        color: red;
    }
    
    .header {
        display: flex;
        align-items: center;
        justify-content: space-between;
        border-bottom: 1px solid #000;
        margin-bottom: -20px;
    }

    .logo {
        flex: 0 0 auto; 
    }

    .details {
        text-align: center;
        flex: 1;
    }
</style>

<?php if($data) : ?>
<body onload="window.print()">

    <div class="header">
        <div class="logo">
            <img width="120" src="<?= base_url('assets/img/logo/'.$per->logo); ?>" alt="Logo">
        </div>
        <div class="details">
            <p class="name-head1">PENYELESAIAN UANG MUKA</p>
            <p class="name-head2"><?= $per->nama ?></p>
            <p><?= $per->alamat ?></p>
        </div>
    </div>
    
    <hr class="hr_satu">
    <hr class="hr_dua">

    <p style="padding-top:30px">Yang bertandatangan dibawah ini :</p>
   
        <table>
            <tr>
                <td>Nama</td>
                <td>: <b><?= $data->nama_user ?></b></td>
            </tr>
            <tr>
                <td>Unit Kerja / Jabatan</td>
                <td>: <em><?= $data->jabatan_user ?></em></td>
            </tr>
        </table>
    <br>
    <p>Dengan ini menerangkan bahwa akan menyelesaikan penggunaan Uang Muka dengan data sbb :</p>
    
        <table>
            <tr>
                <td>Nama Pengguna Uang Muka</td>
                <td>: <b><?= $data->nama_user ?></b></td>
            </tr>
            <tr>
                <td>Jumlah Uang Muka</td>
                <td>: <em><?= 'Rp. ' . $data->nominal ?></em></td>
            </tr>
            <tr>
                <td>Tanggal Uang Muka</td>
                <td>: <?= mediumdate_indo($data->jadwal) ?></td>
            </tr>
            <tr>
                <td>Tanggal Jatuh Tempo</td>
                <td>: <?= mediumdate_indo($data->jatuh_tempo) ?></td>
            </tr>
            <tr>
                <td>Nama Kegiatan</td>
                <td>: <?= $data->kegiatan ?></td>
            </tr>
        </table>
    <br>

    <p>Adapun perincian penggunaan Uang Muka tersebut adalah sebagai berikut :</p>
   
        <div><?= $data->rincian ?></div>
        <br>

        <table class="ttd" style="margin-top:10px;">
            <tbody style="float: right;">
                <tr>
                    <td colspan="2" style="text-align: right;">
                        <b>Jumlah</b>
                    </td>
                    <td colspan="2">
                        <b>: <?= 'Rp. ' . $data->nominal ?></b>
                    </td>
                </tr>
                <tr>
                    <td colspan="2" style="text-align: right;">
                        <b>Permohonan Pengajuan Uang Muka</b>
                    </td>
                    <td colspan="2">
                        <b>: <?= 'Rp. ' . $data->biaya ?></b>
                    </td>
                </tr>
                <tr>
                    <td colspan="2" style="text-align: right;">
                        <b>Kelebihan/Kekurangan</b>
                    </td>
                    <td colspan="2">
                        <b>: -</b>
                    </td>
                </tr>
            </tbody>
        </table>

        <br>
        <p>Demikian saya sampaikan,</p>

        <div class="clearfix">
            <table class="table-left" style="margin-top:10px;">
                <tbody style="float: left;">
                    <tr>
                        <td colspan="2" class="ttd-kanan">
                            <b><br></b>
                            <p>Mengetahui</p>
                        </td>
                    </tr>
                    <tr>
                        <td colspan="2" class="ttd-kanan">
                            <?php if($data->ttd_penandatangan) : ?>
                            <p style="margin: -35px 0 -40px 60px;"><img src="<?= base_url('assets/img/ttd/'.$data->ttd_penandatangan) ?>" alt="logo1" width="200"><br /></p>
                            <?php else : ?>
                            <p style="margin: -35px 0 50px 60px;"><br /></p>
                            <?php endif ?>
                            <p><b style="text-transform: uppercase; text-decoration: underline;"><?= strtoupper($data->nama_penandatangan) ?></b>
                            <br/>(<?= $data->ttd_jabatan ?>)</p>
                        </td>
                    </tr>
                </tbody>
            </table>

            <table class="table-right" style="margin-top:10px;">
                <tbody style="float: right;">
                    <tr>
                        <td colspan="2" class="ttd-kanan">
                            <p><b><?= $data->tempat ?>, <?= mediumdate_indo($data->tgl_rk) ?></b><br>
                            Pemohon</p>
                        </td>
                    </tr>
                    <tr>
                        <td colspan="2" class="ttd-kanan">
                            <p style="margin: -35px 0 50px 60px;"><br /></p>
                            <p><b style="text-transform: uppercase; text-decoration: underline;"><?= strtoupper($data->nama_user) ?></b>
                            <br/>(<?= $data->jabatan_user ?>)</p>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
 
</body>
<?php endif; ?>

</html>