<?php $notif = notif() ?>
<body class="hold-transition sidebar-mini">
<div class="wrapper">
  <!-- Navbar -->
  <nav class="main-header navbar navbar-expand navbar-white navbar-light">
    <!-- Left navbar links -->
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
      </li>
      <li class="nav-item d-none d-sm-inline-block">
        <a href="index3.html" class="nav-link">Home</a>
      </li>
      <li class="nav-item d-none d-sm-inline-block">
        <a href="#" class="nav-link">Contact</a>
      </li>
    </ul>

    <!-- Right navbar links -->
    <ul class="navbar-nav ml-auto">
      <!-- Navbar Search -->
      <li class="nav-item">
        <a class="nav-link" data-widget="navbar-search" href="#" role="button">
          <i class="fas fa-search"></i>
        </a>
        <div class="navbar-search-block">
          <form class="form-inline">
            <div class="input-group input-group-sm">
              <input class="form-control form-control-navbar" type="search" placeholder="Search" aria-label="Search">
              <div class="input-group-append">
                <button class="btn btn-navbar" type="submit">
                  <i class="fas fa-search"></i>
                </button>
                <button class="btn btn-navbar" type="button" data-widget="navbar-search">
                  <i class="fas fa-times"></i>
                </button>
              </div>
            </div>
          </form>
        </div>
      </li>

      <!-- Messages Dropdown Menu -->
      <li class="nav-item dropdown">
        <a class="nav-link" data-toggle="dropdown" href="#">
          <i class="far fa-comments"></i>
          <span class="badge badge-danger navbar-badge">0</span>
        </a>
        <div class="dropdown-menu dropdown-menu-lg dropdown-menu-right">
          <a href="#" class="dropdown-item">
            <!-- Message Start -->
            <!-- <div class="media">
              <img src="<?= base_url('assets/'); ?>dist/img/user1-128x128.jpg" alt="User Avatar" class="img-size-50 mr-3 img-circle">
              <div class="media-body">
                <h3 class="dropdown-item-title">
                  Brad Diesel
                  <span class="float-right text-sm text-danger"><i class="fas fa-star"></i></span>
                </h3>
                <p class="text-sm">Call me whenever you can...</p>
                <p class="text-sm text-muted"><i class="far fa-clock mr-1"></i> 4 Hours Ago</p>
              </div>
            </div> -->
            <!-- Message End -->
          </a>
          <div class="dropdown-divider"></div>
       
          <a href="#" class="dropdown-item dropdown-footer">See All Messages</a>
        </div>
      </li>
      <!-- Notifications Dropdown Menu -->
      <li class="nav-item dropdown">
        <a class="nav-link" data-toggle="dropdown" href="#">
          <i class="far fa-bell"></i>
          <span class="badge badge-warning navbar-badge">0</span>
        </a>
        <div class="dropdown-menu dropdown-menu-lg dropdown-menu-right">
          <span class="dropdown-item dropdown-header">0 Notifications</span>
          <div class="dropdown-divider"></div>
          <a href="#" class="dropdown-item">
            <i class="fas fa-envelope mr-2"></i> 4 new messages
            <span class="float-right text-muted text-sm">3 mins</span>
          </a>
          <div class="dropdown-divider"></div>
        
          <a href="#" class="dropdown-item dropdown-footer">See All Notifications</a>
        </div>
      </li>
      <li class="nav-item">
        <a class="nav-link" data-widget="fullscreen" href="#" role="button">
          <i class="fas fa-expand-arrows-alt"></i>
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link" data-widget="control-sidebar" data-slide="true" href="#" role="button">
          <i class="fas fa-th-large"></i>
        </a>
      </li>
    </ul>
  </nav>
  <!-- /.navbar -->
  
  <!-- Main Sidebar Container -->
  <aside class="main-sidebar sidebar-dark-primary elevation-4">
    <!-- Brand Logo -->
    <a href="index3.html" class="brand-link">
      <img src="<?= base_url('assets/'); ?>dist/img/AdminLTELogo.png" alt="AdminLTE Logo" class="brand-image img-circle elevation-3" style="opacity: .8">
      <span class="brand-text font-weight-light">Kasbon</span>
    </a>

    <!-- Sidebar -->
    <div class="sidebar">
      <!-- Sidebar user panel (optional) -->
      <div class="user-panel mt-3 pb-3 mb-3 d-flex">
        <div class="image">
          <img src="<?= base_url('assets/'); ?>dist/img/avatar5.png" class="img-circle elevation-2" alt="User Image">
        </div>
        <div class="info">
          <a href="#" class="d-block"><?= $user['name'] ?></a>
        </div>
      </div>

      <!-- SidebarSearch Form -->
      <div class="form-inline">
        <div class="input-group" data-widget="sidebar-search">
          <input class="form-control form-control-sidebar" type="search" placeholder="Search" aria-label="Search">
          <div class="input-group-append">
            <button class="btn btn-sidebar">
              <i class="fas fa-search fa-fw"></i>
            </button>
          </div>
        </div>
      </div>

      <!-- Sidebar Menu -->
      <nav class="mt-2">
        <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
          <!-- Add icons to the links using the .nav-icon class
               with font-awesome or any other icon font library -->
       
          <li class="nav-item">
            <a href="<?= base_url(); ?>" class="nav-link <?= ($this->uri->segment(1) == "dashboard") ? "active" : "" ?>">
              <i class="nav-icon fas fa-tachometer-alt"></i>
              <p>
                 Dashboard
              </p>
            </a>
          </li>

          <!-- <li class="nav-item">
            <a href="<?= base_url('approve_request') ?>" class="nav-link <?= ($this->uri->segment(1) == "approve_request") ? "active" : "" ?>">
              <i class="far fa-bell nav-icon"></i>
              <p>Approve Request</p>
            </a>
          </li>

          <li class="nav-item">
            <a href="<?= base_url('riwayat') ?>" class="nav-link <?= ($this->uri->segment(1) == "riwayat") ? "active" : "" ?>">
              <i class="far fa-circle nav-icon"></i>
              <p>Riwayat</p>
            </a>
          </li> -->

              
          <li class="nav-item <?= ($title == "Data Uang Muka") | ($title == "Data Bukti Penerimaan") | ($title == "Data Penyelesaian") ? "menu-open" : "" ?>">
            <a href="#" class="nav-link <?= ($title == "Data Uang Muka") | ($title == "Data Bukti Penerimaan") | ($title == "Data Penyelesaian") ? "active" : "" ?>">
              <i class="nav-icon fas fa-list"></i>
              <p>
                Master Data 
                <i class="fas fa-angle-left right"></i>
                <?php if($user['role_id'] == '2' || $user['role_id'] == '3' || $user['role_id'] == '4') : ?>
                <?php if ($notif->notif_all) : ?>
                  <span class="right badge badge-danger">New</span>
                <?php endif; ?>
                <?php endif; ?>
                
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="<?= base_url('rencana_kegiatan/data') ?>" class="nav-link <?= ($title == "Data Uang Muka") ? "active" : "" ?>">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Data Uang Muka
                  <?php if($user['role_id'] == '2' || $user['role_id'] == '3' || $user['role_id'] == '4') : ?>
                    <?php if ($notif->notif_rk) : ?>
                      <span class="right badge badge-danger"><?= $notif->notif_rk ?></span>
                    <?php endif; ?>
                  <?php endif; ?>
                  </p>
                </a>
              </li>
              <li class="nav-item">
                <a href="<?= base_url('penyelesaian/data'); ?>" class="nav-link <?= ($title == "Data Penyelesaian") ? "active" : "" ?>">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Penyelesaian 
                  <?php if($user['role_id'] == '2' || $user['role_id'] == '3' || $user['role_id'] == '4') : ?>
                    <?php if ($notif->notif_py) : ?>
                      <span class="right badge badge-danger"><?= $notif->notif_py ?></span>
                    <?php endif; ?>
                  <?php endif; ?>
                  </p>
                </a>
              </li>
            </ul>
          </li>

          <?php if($user['role_id'] == '5') : ?>
          <li class="nav-item <?= ($title == "Rencana Kegiatan") | ($title == "Pengajuan Penyelesaian") | ($title == "Penyelesaian") ? "menu-open" : "" ?>">
            <a href="#" class="nav-link <?= ($title == "Rencana Kegiatan") | ($title == "Pengajuan Penyelesaian") | ($title == "Penyelesaian") ? "active" : "" ?>">
              <i class="nav-icon fas fa-money-bill-wave"></i>
              <p>
                Pengajuan
                <i class="fas fa-angle-left right"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="<?= base_url('rencana_kegiatan') ?>" class="nav-link <?= ($title == "Rencana Kegiatan") ? "active" : "" ?>">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Rencana Kegiatan</p>
                </a>
              </li>
              <!-- <li class="nav-item">
                <a href="<?= base_url('bukti_penerimaan'); ?>" class="nav-link <?= ($title == "Bukti Penerimaan") ? "active" : "" ?>">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Bukti Penerimaan</p>
                </a>
              </li> -->
              <li class="nav-item">
                <a href="<?= base_url('data_penyelesaian'); ?>" class="nav-link <?= ($title == "Pengajuan Penyelesaian") ? "active" : "" ?>">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Penyelesaian</p>
                </a>
              </li>
            </ul>
          </li>
          <?php endif; ?>
        
          <?php if($user['role_id'] == '1') : ?>
          <li class="nav-item <?= ($title == "Data User") | ($title == "Tambah User") ? "menu-open" : "" ?>">
            <a href="#" class="nav-link <?= ($title == "Data User") | ($title == "Tambah User") | ($title == "Edit User") ? "active" : "" ?>">
              <i class="nav-icon fas fa-users"></i>
              <p>
                Karyawaan
                <i class="fas fa-angle-left right"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="<?= base_url('data_user') ?>" class="nav-link <?= ($title == "Data User") ? "active" : "" ?>">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Data Karyawan</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="<?= base_url('data_user/tambah_user') ?>" class="nav-link <?= ($title == "Tambah User") ? "active" : "" ?>">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Tambah karyawan</p>
                </a>
              </li>
            </ul>
          </li>
        
          <li class="nav-header">Master Data</li>

            <li class="nav-item">
              <a href="<?= base_url('data_divisi') ?>" class="nav-link <?= ($title == "Data Group") ? "active" : "" ?>">
                <i class="nav-icon fas fa-id-card"></i>
                <p>Data Group</p>
              </a>
            </li>
            <?php endif; ?>
          
          <li class="nav-header">Setting</li>
       
          <li class="nav-item">
            <a href="<?= base_url('data_akun') ?>" class="nav-link <?= ($title == "Data Akun") ? "active" : "" ?>">
              <i class="nav-icon fas fa-user-circle"></i>
              <p>Akun</p>
            </a>
          </li>
       
          <?php if($user['role_id'] == '1') : ?>
          <li class="nav-item">
            <a href="<?= base_url('data_perusahaan') ?>" class="nav-link <?= ($title == "Data Perusahaan") ? "active" : "" ?>">
              <i class="nav-icon fas fa-building"></i>
              <p>Perusahaan</p>
            </a>
          </li>
          <?php endif; ?>

          <li class="nav-item">
            <a href="#" class="nav-link" onclick="Logout();">
              <i class="nav-icon fas fa-sign-out-alt text-danger"></i>
              <p>Logout</p>
            </a>
          </li>
        </ul>
      </nav>
      <!-- /.sidebar-menu -->
    </div>
    <!-- /.sidebar -->
  </aside>
