<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1><?= $title ?></h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="#">Home</a></li>
                        <li class="breadcrumb-item active"><?= $title ?></li>
                    </ol>
                </div>
            </div>
        </div>
    </section>

    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <?= $this->session->flashdata('message'); ?>
                        <div class="card-header">
                            <h3 class="card-title"><?= $title ?></h3>
                        </div>
                        <!-- /.card-header -->
                        <div class="card-body">
                            <div id="example1_wrapper" class="dataTables_wrapper dt-bootstrap4 no-footer">
                               
                                <table id="example1" class="table table-bordered table-striped dataTable no-footer dtr-inline collapsed" aria-describedby="example1_info">
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>Status Persetujuan</th>
                                            <th>Pengirim</th>
                                            <th>Kegiatan</th>
                                            <th>Nominal</th>
                                            <th>Jadwal</th>
                                            <th>Jatuh Tempo</th>
                                            <th>Aksi</th>
                                        </tr>
                                    </thead>
                                    <tbody>       
                                        
                                    <?php $no=1; foreach($data as $d) : ?>
                                    <?php
                                        if ($d->status == 'Pending') {
                                            $btn_st = 'btn-warning';
                                            $icn = 'fa-clock';
                                        }elseif($d->status == 'Approve') {
                                            $btn_st = 'btn-success';
                                            $icn = 'fa-check-circle';
                                        }elseif($d->status == 'Ditolak') {
                                            $btn_st = 'btn-danger';
                                            $icn = 'fa-times-circle';
                                        }
                                        
                                        if ($d->status_fin == 'Pending') {
                                            $btn_st_fin = 'btn-warning';
                                            $icn_fin = 'fa-clock';
                                        }elseif($d->status_fin == 'Approve') {
                                            $btn_st_fin = 'btn-success';
                                            $icn_fin = 'fa-check-circle';
                                        }elseif($d->status_fin == 'Ditolak') {
                                            $btn_st_fin = 'btn-danger';
                                            $icn_fin = 'fa-times-circle';
                                        }
                                    ?>
                                        <tr class="odd">
                                            <td><?= $no++ ?></td>
                                            <td>
                                                <button class="btn <?= $btn_st ?> btn-sm"><i class="fas <?= $icn ?>"></i> <?= $d->status ?></button>
                                                <?php if($d->approval == 'GH') : ?>
                                                    <button class="btn btn-primary btn-sm"><i class="fas fa-check-circle"></i> Approve GH</button>
                                                <?php elseif($d->approval == 'FIN') : ?>
                                                    <button class="btn btn-primary btn-sm"><i class="fas fa-check-circle"></i> Approve Finance</button>
                                                <?php endif; ?>

                                                <?php if($d->status == 'Ditolak') : ?>
                                                    <?php if($user['role_id'] == '1' || $user['role_id'] == '5') : ?>
                                                        <button class="btn btn-info btn-sm view-btn" data-id="<?= $d->id_rk ?>" data-toggle="modal" data-target="#viewAlasan"><i class="fas fa-eye"></i> Lihat Alasan</button>
                                                    <?php elseif ($user['role_id'] == '2' || $user['role_id'] == '3' || $user['role_id'] == '4') : ?>
                                                        <button class="btn btn-info btn-sm edit-alasan" data-id="<?= $d->id_rk ?>" data-toggle="modal" data-target="#editAlasan"><i class="fas fa-eye"></i> Edit Alasan</button>
                                                    <?php endif; ?>
                                                <?php endif; ?>
                                            </td>
                                            <td><?= $d->nama_user ?></td>
                                            <td><?= $d->kegiatan ?></td>
                                            <td><?= 'Rp. ' . $d->nominal ?></td>
                                            <td><?= mediumdate_indo($d->jadwal) ?></td>
                                            <td><?= mediumdate_indo($d->jatuh_tempo) ?></td>
                                            <td>
                                            <?php if ($user['divisi_id'] == '1') : ?>
                                                <?php if($user['role_id'] == '2' || $user['role_id'] == '3' || $user['role_id'] == '4') : ?>
                                                    <?php if($d->status_fin == 'Approve') : ?>
                                                        <button class="btn btn-success btn-sm"><i class="fas fa-check-circle"></i> Diterima</button>
                                                    <?php else : ?>
                                                        <a href="<?= base_url('penyelesaian/detail?id='.$d->id_rk) ?>" class="btn btn-primary btn-xs"><i class="fa fa-eye"></i> View</a>

                                                        <div class="btn-group">
                                                            <button type="button" class="btn <?= $btn_st_fin ?> btn-xs" data-toggle="dropdown" aria-expanded="false"><?= $d->status_fin ?></button>
                                                            <button type="button" class="btn <?= $btn_st_fin ?> btn-xs dropdown-toggle dropdown-icon"></button>
                                                            <div class="dropdown-menu" role="menu" style="">
                                                                <a class="dropdown-item approve-btn-fin" href="#" data-id="<?= $d->id_rk ?>">Approve</a>
                                                            </div>
                                                        </div>
                                                    <?php endif; ?> 
                                                <?php elseif ($user['role_id'] == '5') : ?>
                                                    <?php if($d->status == 'Approve') : ?>
                                                        <a target="_blank" href="<?= base_url('rencana_kegiatan/cetak?id='.$d->id_rk) ?>" class="btn btn-info btn-xs"><i class="fa fa-print"></i> Print</a>
                                                    <?php else : ?>
                                                        <a href="<?= base_url('rencana_kegiatan/update?id='.$d->id_rk) ?>" class="btn btn-primary btn-xs"><i class="fa fa-edit"></i> Edit</a>
                                                        <?php if($d->status == 'Pending') : ?>
                                                            <a href="#" class="btn btn-danger btn-xs delete-btn" data-id="<?= $d->id_rk ?>"><i class="fa fa-trash"></i> Hapus</a>
                                                        <?php endif; ?>
                                                    <?php endif; ?>
                                                <?php elseif ($user['role_id'] == '1') : ?>
                                                    <button class="btn <?= $btn_st ?> btn-sm"><i class="fas <?= $icn ?>"></i> <?= $d->status ?></button>
                                                <?php endif; ?>
                                            <?php else : ?>
                                                <?php if($d->status == 'Approve') : ?>
                                                    <?php if ($user['role_id'] == '5') : ?>
                                                        <?php if($d->approval == 'GH') : ?>
                                                            <?php if($d->status_fin == 'Pending') : ?>
                                                                <button class="btn btn-warning btn-sm"><i class="fas fa-clock"></i> Pending Finance</button>
                                                            <?php else : ?>
                                                                <a href="#" class="btn btn-success btn-xs teruskan-btn" data-id="<?= $d->id_rk ?>"><i class="fa fa-share"></i> Teruskan ke Finance</a>
                                                            <?php endif; ?>
                                                        <?php elseif($d->approval == 'FIN') : ?>
                                                            <a target="_blank" href="<?= base_url('rencana_kegiatan/cetak?id='.$d->id_rk) ?>" class="btn btn-info btn-xs"><i class="fa fa-print"></i> Print</a>
                                                        <?php endif; ?>
                                                    <?php else : ?>
                                                    <a href="<?= base_url('penyelesaian/detail?id='.$d->id_rk) ?>" class="btn btn-primary btn-xs"><i class="fa fa-eye"></i> View</a>
                                                    <?php endif; ?>
                                                <?php else : ?>
                                                    <?php if ($user['role_id'] == '5') : ?>
                                                        <a href="<?= base_url('rencana_kegiatan/update?id='.$d->id_rk) ?>" class="btn btn-primary btn-xs"><i class="fa fa-edit"></i> Edit</a>
                                                        <?php if($d->status == 'Pending') : ?>
                                                        <a href="#" class="btn btn-danger btn-xs delete-btn" data-id="<?= $d->id_rk ?>"><i class="fa fa-trash"></i> Hapus</a>
                                                        <?php endif; ?>
                                                    <?php elseif ($user['role_id'] == '1') : ?>
                                                        <?php if($d->status !== 'Approve') : ?>
                                                        <button class="btn <?= $btn_st ?> btn-sm"><i class="fas <?= $icn ?>"></i> <?= $d->status ?></button>
                                                        <?php endif; ?>
                                                    <?php endif; ?>
                                                <?php endif; ?>
                                                
                                                <?php if ($user['role_id'] == '2' || $user['role_id'] == '3' || $user['role_id'] == '4') : ?>
                                                    <?php if($d->status !== 'Approve') : ?>
                                                        <a href="<?= base_url('penyelesaian/detail?id='.$d->id_rk) ?>" class="btn btn-primary btn-xs"><i class="fa fa-eye"></i> View</a>
                                                        <div class="btn-group">
                                                            <button type="button" class="btn <?= $btn_st ?> btn-xs" data-toggle="dropdown" aria-expanded="false"><?= $d->status ?></button>
                                                            <button type="button" class="btn <?= $btn_st ?> btn-xs dropdown-toggle dropdown-icon"></button>
                                                            <div class="dropdown-menu" role="menu" style="">
                                                                <?php if($d->status !== 'Approve') : ?>
                                                                <a class="dropdown-item approve-btn" href="#" data-id="<?= $d->id_rk ?>">Approve</a>
                                                                <?php endif; ?>
                                                                <?php if($d->status !== 'Ditolak') : ?>
                                                                <a class="dropdown-item ditolak-btn" href="#" data-toggle="modal" data-id="<?= $d->id_rk ?>" data-target="#tolakData">Ditolak</a>
                                                                <?php endif; ?>
                                                            </div>
                                                        </div>
                                                    <?php endif; ?>
                                                <?php endif; ?>
                                            <?php endif; ?>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>

                                    </tbody>
                                </table>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>


<div class="modal fade" id="viewAlasan" role="dialog" aria-labelledby="dataDataLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="dataDataLabel">Alasan Penolakan</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
                <div class="modal-body">

                    <div class="form-group">
                        <label>Alasan Penolakan</label>
                        <textarea type="text" class="form-control" id="viewalasan" placeholder="Alasan Penolakan" disabled></textarea>
                    </div>

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <?php if ($user['role_id'] == '5') : ?>
                    <a href="" type="button" class="btn btn-primary" id="edit-surat"><i class="fas fa-edit"></i> Edit Data</a>
                    <?php endif ?>
                </div>
        </div>
    </div>
</div>

<div class="modal fade" id="editAlasan" role="dialog" aria-labelledby="dataDataLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="dataDataLabel">Edit Alasan Penolakan</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form action="<?= base_url('rencana_kegiatan/edit_alasan'); ?>" method="post">
                <input type="hidden" name="id" id="id_data_edit">
                <div class="modal-body">
                    <div class="form-group">
                        <label>Alasan Penolakan</label>
                        <textarea type="text" class="form-control" name="alasan" id="alasan-edit" placeholder="Alasan Penolakan"></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-primary" id="simpan-edit">Edit Alasan</button>
                    <input hidden type="submit" id="submit-edit">
                </div>
            </form>
        </div>
    </div>
</div>

<div class="modal fade" id="tolakData" role="dialog" aria-labelledby="dataDataLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="dataDataLabel">Penolakan Data</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form action="<?= base_url('rencana_kegiatan/ditolak'); ?>" method="post">
                <input type="hidden" name="id" id="id_data">
                <div class="modal-body">

                    <div class="form-group">
                        <label>Alasan Penolakan</label>
                        <textarea type="text" class="form-control" name="alasan" id="alasan" placeholder="Alasan Penolakan"></textarea>
                        <div id="err-alasan" class='invalid-feedback'>Alasan penolakan harus diisi.</div>
                    </div>

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-danger" id="simpan">Tolak Data</button>
                    <input hidden type="submit" id="submit">
                </div>
            </form>
        </div>
    </div>
</div>


<script>
$(document).ready(function(){

    //view
    $('.view-btn').click(function(e){
        const id = $(this).data('id');
        $.ajax({
            url: '<?= site_url('get/get_data_rk') ?>',
            data: {
                id: id
            },
            method: 'post',
            dataType: 'json',
            success: function(data) {
                $('#viewalasan').val(data.alasan);
                $('#edit-surat').attr('href', '<?= base_url('rencana_kegiatan/update?id=') ?>' + data.id_rk);
            }
        });
    });

    //Ditolak
    $('.ditolak-btn').click(function(e){
        const id = $(this).data('id');
        $.ajax({
            url: '<?= site_url('get/get_data_rk') ?>',
            data: {
                id: id
            },
            method: 'post',
            dataType: 'json',
            success: function(data) {
                $('#id_data').val(data.id_rk);
            }
        });
    });

    //alsan
    $('.edit-alasan').click(function(e){
        const id = $(this).data('id');
        $.ajax({
            url: '<?= site_url('get/get_data_rk') ?>',
            data: {
                id: id
            },
            method: 'post',
            dataType: 'json',
            success: function(data) {
                $('#id_data_edit').val(data.id_rk);
                $('#alasan-edit').val(data.alasan);
            }
        });
    });


    //Approved
    $('.approve-btn').click(function(e){
        e.preventDefault();
        var data = $(this).data('id');
        
        Swal.fire({
            title: 'Approve Data!',
            text: "Apakah anda yakin ingin Approve data!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Ya, Approve!'
        }).then((result) => {
            if (result.isConfirmed) {
                $.ajax({
                    type: 'POST',
                    url: '<?= site_url('rencana_kegiatan/approve') ?>',
                    data: { id: data },
                    success: function(response) {
                        Swal.fire(
                            'Approved!',
                            'Data berhasil Approve.',
                            'success'
                        ).then((result) => {
                            if (result.isConfirmed || result.dismiss === Swal.DismissReason.backdrop) {
                                $.ajax({
                                    type: "POST",
                                    url: "<?= site_url('get/set_flashdata'); ?>",
                                    data: { message: "<strong>Success!</strong> Berhasil Approve data!" },
                                    success: function(response) {
                                        window.location = "<?= base_url('rencana_kegiatan/data'); ?>";
                                    }
                                });
                            }
                        });
                    }
                });
            }
        });
    });

    //Approved Finance
    $('.approve-btn-fin').click(function(e){
        e.preventDefault();
        var data = $(this).data('id');
        
        Swal.fire({
            title: 'Approve Data!',
            text: "Apakah anda yakin ingin Approve data!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Ya, Approve!'
        }).then((result) => {
            if (result.isConfirmed) {
                $.ajax({
                    type: 'POST',
                    url: '<?= site_url('rencana_kegiatan/approve_fin') ?>',
                    data: { id: data },
                    success: function(response) {
                        Swal.fire(
                            'Approved!',
                            'Data berhasil Approve.',
                            'success'
                        ).then((result) => {
                            if (result.isConfirmed || result.dismiss === Swal.DismissReason.backdrop) {
                                $.ajax({
                                    type: "POST",
                                    url: "<?= site_url('get/set_flashdata'); ?>",
                                    data: { message: "<strong>Success!</strong> Berhasil Approve data!" },
                                    success: function(response) {
                                        window.location = "<?= base_url('rencana_kegiatan/data'); ?>";
                                    }
                                });
                            }
                        });
                    }
                });
            }
        });
    });

    $("#simpan").on('click', function(){
        $(".is-invalid").removeClass("is-invalid");
        $(".invalid-feedback").removeClass("d-block");
        
        var alasan = $("#alasan").val();
        if (alasan == '') { 
            $("#alasan").addClass("is-invalid").after("");
            $("#err-alasan").addClass("d-block");
            $("#alasan").focus();
        }
        if ($(".is-invalid").length === 0) {
            swal.fire({
                title: "Yakin ingin menolak data?",
                icon: "info",
                showCancelButton: true,
                // confirmButtonColor: "#DC3545",
                confirmButtonText: "<i class='fa fa-check'></i> Tolak",
                cancelButtonText: "<i class='fa fa-times'></i> Batal",
                closeOnConfirm: false,
                closeOnCancel: false
            }).then(function (result) {
                if (result.value) {
                    Swal.fire(
                        'Berhasil!',
                        'Data berhasil ditolak.',
                        'success'
                    ).then((result) => {
                        $('#submit').trigger('click');
                    });
                } else {
                    swal.fire({
                        title: "Membatalkan!",
                        icon: 'error',
                        confirmButtonText: '<i class="fa fa-thumbs-up"></i> Oke!',
                    });
                }
            });
        }
    });

    $("#simpan-edit").on('click', function(){
        swal.fire({
            title: "Yakin ingin mengubah alasan penolakan?",
            icon: "info",
            showCancelButton: true,
            // confirmButtonColor: "#DC3545",
            confirmButtonText: "<i class='fa fa-check'></i> Tolak",
            cancelButtonText: "<i class='fa fa-times'></i> Batal",
            closeOnConfirm: false,
            closeOnCancel: false
        }).then(function (result) {
            if (result.value) {
                Swal.fire(
                    'Berhasil!',
                    'Data berhasil diupdate.',
                    'success'
                ).then((result) => {
                    $('#submit-edit').trigger('click');
                });
            } else {
                swal.fire({
                    title: "Membatalkan!",
                    icon: 'error',
                    confirmButtonText: '<i class="fa fa-thumbs-up"></i> Oke!',
                });
            }
        });
    });

    $('.teruskan-btn').click(function(e){
        e.preventDefault();
        var deleteId = $(this).data('id');
        
        Swal.fire({
            title: 'Teruskan Data!',
            text: "Apakah anda yakin ingin meneruskan ke Finance?",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Ya, Teruskan!'
        }).then((result) => {
            if (result.isConfirmed) {
                $.ajax({
                    type: 'POST',
                    url: '<?= site_url('rencana_kegiatan/teruskan') ?>',
                    data: { id: deleteId },
                    success: function(response) {
                        Swal.fire(
                            'Success!',
                            'Data berhasil diteruskan ke finance.',
                            'success'
                        ).then((result) => {
                            if (result.isConfirmed || result.dismiss === Swal.DismissReason.backdrop) {
                                location.reload();
                            }
                        });
                    }
                });
            }
        });
    });

    $('.delete-btn').click(function(e){
        e.preventDefault();
        var deleteId = $(this).data('id');
        
        Swal.fire({
            title: 'Hapus Data!',
            text: "Apakah anda yakin ingin menghapus data!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Ya, Hapus!'
        }).then((result) => {
            if (result.isConfirmed) {
                $.ajax({
                    type: 'POST',
                    url: '<?= site_url('rencana_kegiatan/hapus') ?>',
                    data: { id: deleteId },
                    success: function(response) {
                        Swal.fire(
                            'Terhapus!',
                            'Data berhasil dihapus.',
                            'success'
                        ).then((result) => {
                            if (result.isConfirmed || result.dismiss === Swal.DismissReason.backdrop) {
                                location.reload();
                            }
                        });
                    }
                });
            }
        });
    });
    
});
</script>