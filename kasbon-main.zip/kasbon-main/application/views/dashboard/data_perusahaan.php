<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1>Data Perusahaan</h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="<?= base_url(); ?>">Home</a></li>
                        <li class="breadcrumb-item active">Data Perusahaan</li>
                    </ol>
                </div>
            </div>
        </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
            <div class="row">
            <div class="col-lg-7 offset-lg-2">
                <?= $this->session->flashdata('message'); ?>    
                    <div class="card card-primary card-tabs">
                        <div class="card-header">
                          <h3>Data Perusahaan</h3>
                        </div>
                        <div class="card-body">
                            <form method="post" action="<?= base_url('data_perusahaan') ?>" enctype="multipart/form-data">
                                <input type="hidden" id="id_perusahaan" name="id_perusahaan" value="<?= $data->id_perusahaan ?>">
                                <div class="form-group">
                                    <label>Nama Perusahaan</label>
                                    <input type="text" class="form-control" id="nama" name="nama" placeholder="Nama Perusahaan" value="<?= $data->nama ?>" require>
                                    <?= form_error('nama', '<small class="text-danger pl-3">', ' </small>') ?>
                                </div>

                                <div class="form-group">
                                    <label>Alamat Perusahaan</label>
                                    <textarea type="text" class="form-control" id="alamat" name="alamat" placeholder="Alamat Perusahaan" require><?= $data->alamat ?></textarea>
                                    <?= form_error('alamat', '<small class="text-danger pl-3">', ' </small>') ?>
                                </div>

                                <div class="form-group row">
                                    <label for="logo" class="col-md-4 col-form-label">Logo Perusahaan</label>
                                    <div class="col-md-4">
                                        <img class="img-fluid" width="150" src="<?= base_url('assets/img/logo/'.$data->logo); ?>" alt="Logo">
                                    </div>
                                    <div class="col-md-8">
                                        <input type="file" class="form-control" id="logo" name="logo" placeholder="Logo Perusahaan" required>
                                    </div>
                                    <?= form_error('logo', '<small class="text-danger pl-3">', '</small>') ?>
                                </div>

                                <button type="button" id="update" class="btn btn-primary btn-block"><i class="fa fa-redo"></i> Simpan Data</button>
                                <input hidden type="submit" id="submit_u">
                            </form>    
                        </div>

                    </div>

                </div>
            </div>
        </div>
    </section>

</div>

<script type="text/javascript">
$("#update").on('click', function(){
    swal.fire({
            title: "Yakin ingin mengupdate data?",
            icon: "warning",
            showCancelButton: true,
            // confirmButtonColor: "#DC3545",
            confirmButtonText: "<i class='fa fa-check'></i> Simpan",
            cancelButtonText: "<i class='fa fa-times'></i> Batal",
            closeOnConfirm: false,
            closeOnCancel: false
        }).then(function (result) {
            if (result.value) {
                swal.fire({
                    title: "Tersimpan!",
                    text: 'Berhasil mengupdate data.',
                    icon: 'success',
                    confirmButtonText: "<i class='fa fa-thumbs-up'></i> Oke!",
                }).then(function(isConfirm) {
                    $('#submit_u').trigger('click');
                });
            } else {
                swal.fire({
                    title: "Membatalkan!",
                    icon: 'error',
                    confirmButtonText: '<i class="fa fa-thumbs-up"></i> Oke!',
                });
            }
        });
});
</script>

<script type="text/javascript">
$(document).on("click", ".browse", function() {
    var file = $(this).parents().find(".file");
    file.trigger("click");
});

$('#imgInp').change(function(e) {
    var fileName = e.target.files[0].name;
    $("#file").val(fileName);

    var reader = new FileReader();
    reader.onload = function(e) {
        // get loaded data and render thumbnail.
        document.getElementById("preview").src = e.target.result;
    };
    // read the image file as a data URL.
    reader.readAsDataURL(this.files[0]);
});
</script>