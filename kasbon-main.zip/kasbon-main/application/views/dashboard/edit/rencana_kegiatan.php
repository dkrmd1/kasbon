<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1>RENCANA KEGIATAN</h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="<?= base_url(); ?>">Home</a></li>
                        <li class="breadcrumb-item active">Rencana Kegiatan</li>
                    </ol>
                </div>
            </div>
        </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">

                    <form method="post" action="<?= base_url('rencana_kegiatan/update') ?>" enctype="multipart/form-data">
                        <input type="hidden" class="form-control" id="id_rk" name="id_rk" value="<?= $data->id_rk ?>">
                        <div class="card">
                            <?= $this->session->flashdata('message'); ?>
                            <div class="card-header">
                                <h3 class="card-title text-bold">Yang bertandatangan dibawah ini :</h3>
                                <div class="card-tools">
                                    <button type="button" class="btn btn-tool" data-card-widget="collapse">
                                        <i class="fas fa-minus"></i>
                                    </button>
                                </div>
                            </div>
                            <!-- /.card-header -->

                            <div class="card-body"> 
                                <div class="row">
                                    <div class="col-lg-6 col-md-6">
                                        <div class="form-group row">
                                            <label class="col-sm-2 col-form-label">Nama</label>
                                            <div class="col-sm-10">
                                                <input type="text" class="form-control" id="nama" name="nama" placeholder="Nama Lengkap" value="<?= $user['name'] ?>" disabled>
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-sm-2 col-form-label">Jabatan</label>
                                            <div class="col-sm-10">
                                                <input type="text" class="form-control" id="jabatan" name="jabatan" placeholder="Jabatan" value="<?= $user['jabatan'] ?>" disabled>
                                            </div>
                                        </div>
                                    </div>
                                
                                </div>
                            </div>
                        </div>


                        <div class="card">
                            <div class="card-header">
                                <h3 class="card-title text-bold">Dengan ini menerangkan bahwa akan melaksanakan kegiatan data sbb:</h3>
                                <div class="card-tools">
                                    <button type="button" class="btn btn-tool" data-card-widget="collapse">
                                        <i class="fas fa-minus"></i>
                                    </button>
                                </div>
                            </div>
                            <!-- /.card-header -->

                            <div class="card-body"> 
                                <div class="row">
                                    <div class="col-lg-6 col-md-6">
                                        <div class="form-group row">
                                            <label class="col-sm-2 col-form-label">Kegiatan</label>
                                            <div class="col-sm-10">
                                                <input type="text" class="form-control" id="kegiatan" name="kegiatan" placeholder="Nama Kegiatan" value="<?= $data->kegiatan ?>">
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-sm-2 col-form-label">Tempat</label>
                                            <div class="col-sm-10">
                                                <input type="text" class="form-control" id="tempat" name="tempat" placeholder="Tempat" value="<?= $data->tempat ?>">
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-sm-3 col-form-label">Jadwal Kegiatan</label>
                                            <div class="col-sm-9">
                                                <div class="input-group date" id="reservationdate" data-target-input="nearest">
                                                    <input type="text" class="form-control datetimepicker-input" data-target="#reservationdate" id="jadwal" name="jadwal" value="<?= $data->jadwal ?>"/>
                                                    <div class="input-group-append" data-target="#reservationdate" data-toggle="datetimepicker">
                                                        <div class="input-group-text"><i class="fa fa-calendar"></i></div>
                                                    </div>
                                                </div>
                                        </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-sm-2 col-form-label">Biaya</label>
                                            <div class="col-sm-10">
                                                <input type="text" class="form-control" id="biaya" name="biaya" placeholder="Perkiraan" value="<?= $data->biaya ?>">
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-sm-2 col-form-label">Jatuh Tempo</label>
                                            <div class="col-sm-10">
                                                <div class="input-group date" id="reservationdate2" data-target-input="nearest">
                                                    <input type="text" class="form-control datetimepicker-input" data-target="#reservationdate2" id="jatuh_tempo" name="jatuh_tempo" value="<?= $data->jatuh_tempo ?>"/>
                                                    <div class="input-group-append" data-target="#reservationdate2" data-toggle="datetimepicker">
                                                        <div class="input-group-text"><i class="fa fa-calendar"></i></div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                               

                                    </div>

                                </div>
                            </div>
                        </div>
                        
                        <div class="card">
                            <div class="card-header">
                                <h3 class="card-title text-bold">Sehubungan dengan hal tersebut, dengan ini mohon persetujuan Bapak/ibu untuk mengajukan Penggunaan Uang Muka sebesar :</h3>
                                <div class="card-tools">
                                    <button type="button" class="btn btn-tool" data-card-widget="collapse">
                                        <i class="fas fa-minus"></i>
                                    </button>
                                </div>
                            </div>
                            <div class="card-body"> 
                                <div class="row">
                                    <div class="col-lg-6 col-md-6">
                                        <div class="form-group row">
                                            <label class="col-sm-2 col-form-label">Nominal</label>
                                            <div class="col-sm-10">
                                                <input type="number" class="form-control" id="nominal" name="nominal" placeholder="Nominal" value="<?= $data->biaya ?>" disabled>
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-sm-2 col-form-label">Terbilang</label>
                                            <div class="col-sm-10">
                                                <input type="text" class="form-control" id="terbilang" name="terbilang" placeholder="Terbilang" value="<?= $data->terbilang ?>">
                                            </div>
                                        </div>
                                       
                                    </div>
                            </div>
                        </div>

                        <div class="card">
                            <div class="card-footer">
                                <button class="btn btn-block btn-primary" type="button" id="update"><i class="fa fa-check"></i> Update Data</button>
                                <input hidden type="submit" id="submit">
                            </div>
                        </div>
                    </form>

                </div>

            </div>
        </div>
    </section>
</div>


<script type="text/javascript">
$(document).ready(function() {
    $('#biaya').on('input', function() {
        $('#nominal').val($(this).val());
    });
});
$("#update").on('click', function(){
    var nama   = $("#nama").val();
    var jabatan   = $("#jabatan").val();
    var kegiatan   = $("#kegiatan").val();
    var tempat   = $("#tempat").val();
    var jadwal   = $("#jadwal").val();
    var biaya   = $("#biaya").val();
    var jatuh_tempo   = $("#jatuh_tempo").val();
    var nominal   = $("#nominal").val();
    var terbilang   = $("#terbilang").val();
    var penandatangan   = $("#penandatangan").val();

    if(nama == '' || jabatan == '' || kegiatan == '' || tempat == '' || jadwal == '' || biaya == '' || jatuh_tempo == '' || nominal == '' || terbilang == '' || penandatangan == ''){
        Swal.fire({
                confirmButtonText: "<i class='fa fa-thumbs-up'></i> Oke!",
                icon: 'warning',
                title: 'Oops!',
                text: 'Data belum lengkap.'
        });
            die;
    } else {

        swal.fire({
            title: "Yakin ingin mengupdate data?",
            icon: "info",
            showCancelButton: true,
            // confirmButtonColor: "#DC3545",
            confirmButtonText: "<i class='fa fa-check'></i> Update",
            cancelButtonText: "<i class='fa fa-times'></i> Batal",
            closeOnConfirm: false,
            closeOnCancel: false
        }).then(function (result) {
            if (result.value) {
                swal.fire({
                    title: "Terupdate!",
                    text: 'Berhasil mengupdate data.',
                    icon: 'success',
                    confirmButtonText: "<i class='fa fa-thumbs-up'></i> Oke!",
                }).then(function(isConfirm) {
                    $('#submit').trigger('click');
                });
            } else {
                swal.fire({
                    title: "Membatalkan!",
                    icon: 'error',
                    confirmButtonText: '<i class="fa fa-thumbs-up"></i> Oke!',
                });
            }
        });
    }
});
</script>