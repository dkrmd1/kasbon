<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1>Yang bertandatangan dibawah ini : </h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="<?= base_url(); ?>">Home</a></li>
                        <li class="breadcrumb-item active">bukti penerimaan</li>
                    </ol>
                </div>
            </div>
        </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">

                    <form method="post" action="<?= base_url('bukti_penerimaan/update') ?>" enctype="multipart/form-data">
                        <input type="hidden" class="form-control" id="id_bp" name="id_bp" value="<?= $data->id_bp ?>">
                        <div class="card">
                            <?= $this->session->flashdata('message'); ?>
                            <div class="card-header">
                                <h3 class="card-title text-bold">BUKTI PENERIMAAN UANG MUKA</h3>
                                <div class="card-tools">
                                    <button type="button" class="btn btn-tool" data-card-widget="collapse">
                                        <i class="fas fa-minus"></i>
                                    </button>
                                </div>
                            </div>
                            <!-- /.card-header -->

                            <div class="card-body"> 
                                <div class="row">
                                    <div class="col-lg-6 col-md-6">
                                        <div class="form-group row">
                                            <label class="col-sm-2 col-form-label">Nama</label>
                                            <div class="col-sm-10">
                                                <input type="text" class="form-control" id="nama" name="nama" placeholder="Nama Lengkap" value="<?= $data->nama ?>">
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-sm-2 col-form-label">Jabatan</label>
                                            <div class="col-sm-10">
                                                <input type="text" class="form-control" id="jabatan" name="jabatan" placeholder="Jabatan" value="<?= $data->jabatan ?>">
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-sm-3 col-form-label">Terima Uang Muka</label>
                                            <div class="col-sm-9">
                                                <input type="text" class="form-control" id="uang_muka" name="uang_muka" placeholder="Uang Muka" value="<?= $data->uang_muka ?>">
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-sm-2 col-form-label">Terbilang</label>
                                            <div class="col-sm-10">
                                                <input type="text" class="form-control" id="terbilang" name="terbilang" placeholder="Terbilang" value="<?= $data->terbilang ?>">
                                            </div>
                                        </div>
                                    </div>
                                
                                </div>
                            </div>
                        </div>


                        <div class="card">
                            <div class="card-header">
                                <h3 class="card-title text-bold">Untuk melaksanakan kegiatan :</h3>
                                <div class="card-tools">
                                    <button type="button" class="btn btn-tool" data-card-widget="collapse">
                                        <i class="fas fa-minus"></i>
                                    </button>
                                </div>
                            </div>
                            <!-- /.card-header -->

                            <div class="card-body"> 
                                <div class="row">
                                    <div class="col-lg-6 col-md-6">
                                        <div class="form-group row">
                                            <label class="col-sm-3 col-form-label">Nama Kegiatan</label>
                                            <div class="col-sm-9">
                                                <input type="text" class="form-control" id="kegiatan" name="kegiatan" placeholder="Nama Kegiatan" value="<?= $data->kegiatan ?>">
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-sm-3 col-form-label">Tempat</label>
                                            <div class="col-sm-9">
                                                <input type="text" class="form-control" id="tempat" name="tempat" placeholder="Tempat" value="<?= $data->tempat ?>">
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-sm-3 col-form-label">Tanggal Waktu</label>
                                            <div class="col-sm-9">
                                                <div class="input-group date" id="reservationdate" data-target-input="nearest">
                                                    <input type="text" class="form-control datetimepicker-input" data-target="#reservationdate" id="waktu" name="waktu" value="<?= $data->waktu ?>"/>
                                                    <div class="input-group-append" data-target="#reservationdate" data-toggle="datetimepicker">
                                                        <div class="input-group-text"><i class="fa fa-calendar"></i></div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-sm-3 col-form-label">Penandatangan</label>
                                            <div class="col-sm-9">
                                                <select class="form-control select2" style="width: 100%" id="penandatangan" name="penandatangan">
                                                    <option value="">--Pilih Orang--</option>
                                                    <?php foreach($data_user as $d) : ?>
                                                        <option value="<?= $d->id_user ?>" <?= ($data->ttd == $d->id_user)? 'selected':'' ?>><?= $d->name ?></option>
                                                    <?php endforeach; ?>
                                                </select>
                                            </div>
                                        </div>
                    

                                    </div>

                                </div>
                            </div>
                        </div>
                        
                        <div class="card">
                            <div class="card-header">
                                <!-- <h3 class="card-title text-bold">note</h3> -->
                                <div class="card-tools">
                                    <button type="button" class="btn btn-tool" data-card-widget="collapse">
                                        <i class="fas fa-minus"></i>
                                    </button>
                                </div>
                            </div>
                            <div class="card-body"> 
                                    <div class="row">
                                        <div class="col-lg-12 col-md-12">
                                            <textarea id="summernote" name="note"><?= $data->note ?></textarea>
                                        </div>
                                    </div>
                            </div>
                        </div>

                        <div class="card">
                            <div class="card-footer">
                                <button class="btn btn-block btn-primary" type="button" id="update"><i class="fa fa-check"></i> Update Data</button>
                                <input hidden type="submit" id="submit">
                            </div>
                        </div>
                    </form>

                </div>

            </div>
        </div>
    </section>
</div>

<script type="text/javascript">
$("#update").on('click', function(){
    var nama       = $("#nama").val();
    var jabatan    = $("#jabatan").val();
    var uang_muka   = $("#uang_muka").val();
    var terbilang  = $("#terbilang").val();
    var kegiatan   = $("#kegiatan").val();
    var tempat   = $("#tempat").val();
    var waktu        = $("#waktu").val();
    var penandatangan   = $("#penandatangan").val();

    if(nama == '' || jabatan == '' || uang_muka == '' || terbilang == '' || kegiatan == '' || tempat == '' || waktu == '' || penandatangan == ''){
        Swal.fire({
                confirmButtonText: "<i class='fa fa-thumbs-up'></i> Oke!",
                icon: 'warning',
                title: 'Oops!',
                text: 'Data belum lengkap.'
        });
        die;
    } else {

        swal.fire({
            title: "Yakin ingin mengupdate data?",
            icon: "info",
            showCancelButton: true,
            // confirmButtonColor: "#DC3545",
            confirmButtonText: "<i class='fa fa-check'></i> Update",
            cancelButtonText: "<i class='fa fa-times'></i> Batal",
            closeOnConfirm: false,
            closeOnCancel: false
        }).then(function (result) {
            if (result.value) {
                swal.fire({
                    title: "Terupdate!",
                    text: 'Berhasil mengupdate data.',
                    icon: 'success',
                    confirmButtonText: "<i class='fa fa-thumbs-up'></i> Oke!",
                }).then(function(isConfirm) {
                    $('#submit').trigger('click');
                });
            } else {
                swal.fire({
                    title: "Membatalkan!",
                    icon: 'error',
                    confirmButtonText: '<i class="fa fa-thumbs-up"></i> Oke!',
                });
            }
        });
    }
});
</script>