<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1>Yang bertandatangan dibawah ini : </h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="<?= base_url(); ?>">Home</a></li>
                        <li class="breadcrumb-item active">bukti penerimaan</li>
                    </ol>
                </div>
            </div>
        </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">

                    <form method="post" action="<?= base_url('bukti_penerimaan/save') ?>" enctype="multipart/form-data">

                        <div class="card">
                            <div class="card-header">
                                <h3 class="card-title text-bold">BUKTI PENERIMAAN UANG MUKA</h3>
                                <div class="card-tools">
                                    <button type="button" class="btn btn-tool" data-card-widget="collapse">
                                        <i class="fas fa-minus"></i>
                                    </button>
                                </div>
                            </div>
                            <!-- /.card-header -->

                            <div class="card-body"> 
                                <div class="row">
                                    <div class="col-lg-6 col-md-6">
                                        <div class="form-group row">
                                            <label class="col-sm-2 col-form-label">Nama</label>
                                            <div class="col-sm-10">
                                                <input type="text" class="form-control" id="nama" name="nama" value="<?= $user['name'] ?>" disabled>
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-sm-2 col-form-label">Jabatan</label>
                                            <div class="col-sm-10">
                                                <input type="text" class="form-control" id="jabatan" name="jabatan" value="<?= $user['jabatan'] ?>" disabled>
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-sm-3 col-form-label">Terima Uang Muka</label>
                                            <div class="col-sm-9">
                                                <input type="number" class="form-control" id="uang_muka" name="uang_muka" placeholder="Uang Muka">
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-sm-2 col-form-label">Terbilang</label>
                                            <div class="col-sm-10">
                                                <input type="text" class="form-control" id="terbilang" name="terbilang" placeholder="Terbilang">
                                            </div>
                                        </div>
                                    </div>
                                
                                </div>
                            </div>
                        </div>


                        <div class="card">
                            <div class="card-header">
                                <h3 class="card-title text-bold">Untuk melaksanakan kegiatan :</h3>
                                <div class="card-tools">
                                    <button type="button" class="btn btn-tool" data-card-widget="collapse">
                                        <i class="fas fa-minus"></i>
                                    </button>
                                </div>
                            </div>
                            <!-- /.card-header -->

                            <div class="card-body"> 
                                <div class="row">
                                    <div class="col-lg-6 col-md-6">
                                        <div class="form-group row">
                                            <label class="col-sm-3 col-form-label">Nama Kegiatan</label>
                                            <div class="col-sm-9">
                                                <input type="text" class="form-control" id="kegiatan" name="kegiatan" placeholder="Nama Kegiatan">
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-sm-3 col-form-label">Tempat</label>
                                            <div class="col-sm-9">
                                                <input type="text" class="form-control" id="tempat" name="tempat" placeholder="Tempat">
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-sm-3 col-form-label">Tanggal Waktu</label>
                                            <div class="col-sm-9">
                                                <div class="input-group date" id="reservationdate" data-target-input="nearest">
                                                    <input type="text" class="form-control datetimepicker-input" data-target="#reservationdate" id="waktu" name="waktu"/>
                                                    <div class="input-group-append" data-target="#reservationdate" data-toggle="datetimepicker">
                                                        <div class="input-group-text"><i class="fa fa-calendar"></i></div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-sm-3 col-form-label">Penandatangan</label>
                                            <div class="col-sm-9">
                                                <select class="form-control select2" style="width: 100%" id="penandatangan" name="penandatangan">
                                                    <option value="">--Pilih Orang--</option>
                                                    <?php foreach($data_user as $d) : ?>
                                                    <option value="<?= $d->id_user ?>"><?= $d->name ?></option>
                                                    <?php endforeach; ?>
                                                </select>
                                            </div>
                                        </div>
                    

                                    </div>

                                </div>
                            </div>
                        </div>
                        
                        <div class="card">
                            <div class="card-header">
                                <!-- <h3 class="card-title text-bold">note</h3> -->
                                <div class="card-tools">
                                    <button type="button" class="btn btn-tool" data-card-widget="collapse">
                                        <i class="fas fa-minus"></i>
                                    </button>
                                </div>
                            </div>
                            <div class="card-body"> 
                                    <div class="row">
                                        <div class="col-lg-12 col-md-12">
                                            <textarea id="summernote" name="note"></textarea>
                                        </div>
                                    </div>
                            </div>
                        </div>

                        <div class="card">
                            <div class="card-footer">
                                <button class="btn btn-block btn-primary" type="button" id="simpan"><i class="fa fa-check"></i> Simpan Data</button>
                                <input hidden type="submit" id="submit">
                            </div>
                        </div>
                    </form>

                </div>

            </div>
        </div>
    </section>
</div>

<script type="text/javascript">
$("#simpan").on('click', function(){
    var nama       = $("#nama").val();
    var jabatan    = $("#jabatan").val();
    var uang_muka   = $("#uang_muka").val();
    var terbilang  = $("#terbilang").val();
    var kegiatan   = $("#kegiatan").val();
    var tempat   = $("#tempat").val();
    var waktu        = $("#waktu").val();
    var penandatangan   = $("#penandatangan").val();

    if(nama == '' || jabatan == '' || uang_muka == '' || terbilang == '' || kegiatan == '' || tempat == '' || waktu == '' || penandatangan == ''){
        Swal.fire({
                confirmButtonText: "<i class='fa fa-thumbs-up'></i> Oke!",
                icon: 'warning',
                title: 'Oops!',
                text: 'Data belum lengkap.'
        });
        die;
    } else {

        swal.fire({
            title: "Yakin ingin menyimpan data?",
            icon: "info",
            showCancelButton: true,
            // confirmButtonColor: "#DC3545",
            confirmButtonText: "<i class='fa fa-check'></i> Simpan",
            cancelButtonText: "<i class='fa fa-times'></i> Batal",
            closeOnConfirm: false,
            closeOnCancel: false
        }).then(function (result) {
            if (result.value) {
                swal.fire({
                    title: "Tersimpan!",
                    text: 'Berhasil menyimpan data.',
                    icon: 'success',
                    confirmButtonText: "<i class='fa fa-thumbs-up'></i> Oke!",
                }).then(function(isConfirm) {
                    $('#submit').trigger('click');
                });
            } else {
                swal.fire({
                    title: "Membatalkan!",
                    icon: 'error',
                    confirmButtonText: '<i class="fa fa-thumbs-up"></i> Oke!',
                });
            }
        });
    }
});
</script>