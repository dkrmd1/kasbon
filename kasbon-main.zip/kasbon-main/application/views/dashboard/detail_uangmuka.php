<?php
if($data){
    if ($data->status == 'Pending') {
        $btn_st = 'btn-warning';
        $icn = 'fa-clock';
        $status = 'Pending';
    }elseif($data->status == 'Approve') {
        $btn_st = 'btn-primary';
        $icn = 'fa-check-circle';
        if($data->approval == 'GH'){
            $status = 'Aprrove GH';
        }elseif($data->approval == 'FIN'){
            $status = 'Aprrove Finance';
        }else{
            $status = 'Aprrove';
        }
    }elseif($data->status == 'Ditolak') {
        $btn_st = 'btn-danger';
        $icn = 'fa-times-circle';
        $status = 'Ditolak';
    }
}
?>
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1><?= $title ?></h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="<?= base_url(); ?>">Home</a></li>
                        <li class="breadcrumb-item active"><?= $title ?></li>
                    </ol>
                </div>
            </div>
        </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <?php if($data) : ?>
                        <div class="card">
                            <div class="card-header">
                                <h3 class="card-title"><?= $title ?></h3>
                            </div>
                            <div class="card-body"> 
                                <table class="table table-xs table-striped table-bordered">
                                    <thead>
                                        <tr>
                                            <th scope="col" class="text-center">Tanggal Masuk <h4 class="text-bold pt-2"><?= longdate_indo($data->tgl_rk) ?></h4></th>
                                            <th scope="col" class="text-center">Jatuh Tempo <h4 class="text-bold pt-2"><?= longdate_indo($data->jatuh_tempo) ?></h4></th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td>Kegiatan</td>
                                            <td><?= $data->kegiatan ?></td>
                                        </tr>
                                        <tr>
                                            <td>Pengirim</td>
                                            <td><?= !empty($data->nama_user) ? $data->nama_user : '-' ?></td>
                                        </tr>
                                        <tr>
                                            <td>Divisi</td>
                                            <td><?= !empty($data->divisi) ? $data->divisi : '-' ?></td>
                                        </tr>
                                        <tr>
                                            <td>Jadwal</td>
                                            <td><?= !empty($data->jadwal) ? longdate_indo($data->jadwal) : '-' ?></td>
                                        </tr>
                                        <tr>
                                            <td>Jatuh Tempo</td>
                                            <td><?= !empty($data->jatuh_tempo) ? longdate_indo($data->jatuh_tempo) : '-' ?></td>
                                        </tr>
                                        <tr>
                                            <td>Biaya</td>
                                            <td><?= !empty($data->biaya) ? $data->biaya : '-' ?></td>
                                        </tr>
                                        <tr>
                                            <td>Terbilang</td>
                                            <td><?= !empty($data->terbilang) ? $data->terbilang : '-' ?></td>
                                        </tr>

                                        <?php if(!empty($data->tgl_persetujuan)) : ?>
                                        <tr>
                                            <td>Persetujuan</td>
                                            <td><?= !empty($data->nama_penandatangan) ? $data->nama_penandatangan : '-' ?></td>
                                        </tr>
                                        <tr>
                                            <td>Tanggal Persetujuan</td>
                                            <td><?= !empty($data->tgl_persetujuan) ? longdate_indo($data->tgl_persetujuan) : '-' ?></td>
                                        </tr>
                                        <?php endif ?>

                                        <tr>
                                            <td>Status Persetujuan</td>
                                            <td><?= !empty($status) ? '<button class="btn '.$btn_st.' btn-sm"><i class="fas '.$icn.'"></i> '.$status.'</button>' : '-' ?></td>
                                        </tr>
                                    </tbody>
                                </table>
                            
                            </div>
                        </div>

                    <?php endif; ?>
                </div>

            </div>
        </div>
    </section>
</div>