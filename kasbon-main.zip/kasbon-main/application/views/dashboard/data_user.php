<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1>Data User</h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="#">Home</a></li>
                        <li class="breadcrumb-item active">Data User</li>
                    </ol>
                </div>
            </div>
        </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="card">
                    <?= $this->session->flashdata('message'); ?>
                        <div class="card-header">
                            <h3 class="card-title">Data User</h3>
                            <div class="card-tools">
                                <a href="<?= base_url('data_user/tambah_user') ?>" class="btn btn-success"><i class="fa fa-plus"></i> Tambah User</a>
                            </div>
                        </div>
                        <!-- /.card-header -->
                        <div class="card-body">
                            <table id="example1" class="table table-bordered table-striped">
                                <thead>
                                    <tr>
                                        <th>Nama</th>
                                        <th>Email</th>
                                        <th>Divisi</th>
                                        <th>Role User</th>
                                        <th>Status</th>
                                        <th>Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                <?php foreach ($data as $d) : ?>
                                <?php 
                                if ($d->role_id == 1) {
                                    $role = "Admin";
                                    $btn_r = "btn-secondary";
                                }elseif ($d->role_id == 2) {
                                    $role = "Direktur Utama";
                                    $btn_r = "btn-success";
                                }elseif ($d->role_id == 3) {
                                    $role = "Direksi";
                                    $btn_r = "btn-info";
                                }elseif ($d->role_id == 4) {
                                    $role = "Group Head";
                                    $btn_r = "btn-warning";
                                }elseif ($d->role_id == 5) {
                                    $role = "Staff";
                                    $btn_r = "btn-primary";
                                }
                                ?>
                                    <tr>
                                        <td><?= $d->name ?></td>
                                        <td><?= $d->email ?></td>
                                        <td><?= $d->nama_divisi ?></td>
                                        <td><button class="btn <?= $btn_r ?> btn-xs"><?= $role ?></button></td>
                                        <td><?= ($d->status == "on") ? 'Aktif' : 'Tidak Aktif'; ?></td>
                                        <td>
                                            <a href="<?= base_url('data_user/edit_user/'.$d->id_user) ?>" class="btn btn-success btn-xs">Edit</a>
                                            <a href="#" class="btn btn-danger btn-xs delete-btn" data-id="<?= $d->id_user ?>">Hapus</a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>

<script>
$(document).ready(function(){
    $('.delete-btn').click(function(e){
        e.preventDefault();
        var deleteId = $(this).data('id');
        
        Swal.fire({
            title: 'Hapus Data!',
            text: "Apakah anda yakin ingin menghapus data!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Ya, Hapus!'
        }).then((result) => {
            if (result.isConfirmed) {
                $.ajax({
                    type: 'POST',
                    url: 'data_user/hapus',
                    data: { id: deleteId },
                    success: function(response) {
                        Swal.fire(
                            'Terhapus!',
                            'Data berhasil dihapus.',
                            'success'
                        ).then((result) => {
                            if (result.isConfirmed || result.dismiss === Swal.DismissReason.backdrop) {
                                location.reload();
                            }
                        });
                    }
                });
            }
        });
    });
});
</script>