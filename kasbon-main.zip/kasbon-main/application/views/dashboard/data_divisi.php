<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1><?= $title ?></h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="<?= base_url('dashboard') ?>">Home</a></li>
                        <li class="breadcrumb-item active"><?= $title ?></li>
                    </ol>
                </div>
            </div>
        </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="card">
                    <?= $this->session->flashdata('message'); ?>
                        <div class="card-header">
                            <h3 class="card-title"><?= $title ?></h3>
                            <div class="card-tools">
                                <a href="#" class="btn btn-success" data-toggle="modal" data-target="#tambahData"><i class="fa fa-plus"></i> Tambah Group</a>
                            </div>
                        </div>
                        <!-- /.card-header -->
                        <div class="card-body">
                            <table id="example1" class="table table-bordered table-striped">
                                <thead>
                                    <tr>
                                        <th>No</th>
                                        <th>Nama Group</th>
                                        <th>Kode Group</th>
                                        <th>Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                <?php $no=1; foreach ($data as $d) : ?>
                                    <tr>
                                        <td><?= $no++ ?></td>
                                        <td><?= $d->divisi ?></td>
                                        <td><?= $d->kode_divisi ?></td>
                                        <?php if($d->id_divisi !== '1') : ?>
                                        <td>
                                            <a href="#" class="tombol-edit btn btn-success btn-xs" data-toggle="modal" data-id="<?= $d->id_divisi; ?>" data-target="#editData">Edit</a>
                                            <a href="#" class="btn btn-danger btn-xs delete-btn" data-id="<?= $d->id_divisi ?>">Hapus</a>
                                        </td>
                                        <?php endif ?>
                                    </tr>
                                <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>


<div class="modal fade" id="tambahData" role="dialog" aria-labelledby="tambahDataLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="tambahDataLabel">Tambah <?= $title; ?></h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form action="<?= base_url('data_divisi/tambah_divisi'); ?>" method="post">
                <div class="modal-body">

                    <div class="form-group">
                        <label>Nama Group</label>
                        <input type="text" class="form-control" name="divisi" placeholder="Nama Group">
                    </div>

                    <div class="form-group">
                        <label>Kode Group</label>
                        <input type="text" class="form-control" name="kode_divisi" placeholder="Kode Group ex. ITGA/M">
                    </div>
                  
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Tambah</button>
                </div>
            </form>
        </div>
    </div>
</div>


<div class="modal fade" id="editData" role="dialog" aria-labelledby="editDataLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="editDataLabel">Edit <?= $title; ?></h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form action="<?= base_url('data_divisi/update_divisi'); ?>" method="post">
                <div class="modal-body">

                    <input type="hidden" name="id" id="id_data">

                    <div class="form-group">
                        <label>Nama Group</label>
                        <input type="text" class="form-control" id="divisi" name="divisi" placeholder="Nama Group">
                    </div>

                    <div class="form-group">
                        <label>Kode Group</label>
                        <input type="text" class="form-control" id="kode_divisi" name="kode_divisi" placeholder="Kode Group ex. ITGA/M">
                    </div>                  
                    
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Update</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
$(document).ready(function(){
    $('.delete-btn').click(function(e){
        e.preventDefault();
        var deleteId = $(this).data('id');
        
        Swal.fire({
            title: 'Hapus Data!',
            text: "Apakah anda yakin ingin menghapus data!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Ya, Hapus!'
        }).then((result) => {
            if (result.isConfirmed) {
                $.ajax({
                    type: 'POST',
                    url: 'data_divisi/hapus',
                    data: { id: deleteId },
                    success: function(response) {
                        Swal.fire(
                            'Terhapus!',
                            'Data berhasil dihapus.',
                            'success'
                        ).then((result) => {
                            if (result.isConfirmed || result.dismiss === Swal.DismissReason.backdrop) {
                                location.reload();
                            }
                        });
                    }
                });
            }
        });
    });
});

$('.tombol-edit').on('click', function() {
    const id = $(this).data('id');
    $.ajax({
        url: 'get/get_data_divisi',
        data: {
            id: id
        },
        method: 'post',
        dataType: 'json',
        success: function(data) {
            $('#id_data').val(data.id_divisi);
            $('#divisi').val(data.divisi);
            $('#kode_divisi').val(data.kode_divisi);
        }
    });
});
</script>