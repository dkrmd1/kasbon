<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1><?= $title ?></h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="#">Home</a></li>
                        <li class="breadcrumb-item active"><?= $title ?></li>
                    </ol>
                </div>
            </div>
        </div>
    </section>

    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <?= $this->session->flashdata('message'); ?>
                        <div class="card-header">
                            <h3 class="card-title"><?= $title ?></h3>
                        </div>
                        <!-- /.card-header -->
                        <div class="card-body">
                            <div id="example1_wrapper" class="dataTables_wrapper dt-bootstrap4 no-footer">
                               
                                <table id="example1" class="table table-bordered table-striped dataTable no-footer dtr-inline collapsed" aria-describedby="example1_info">
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>Status Persetujuan</th>
                                            <th>Pengirim</th>
                                            <th>Kegiatan</th>
                                            <th>Nominal</th>
                                            <th>Jadwal</th>
                                            <th>Jatuh Tempo</th>
                                            <th>Aksi</th>
                                        </tr>
                                    </thead>
                                    <tbody>       
                                        
                                    <?php $no=1; foreach($data as $d) : ?>
                                    <?php
                                         if ($d->status_py == 'Pending') {
                                            $btn_st = 'btn-warning';
                                            $icn = 'fa-clock';
                                            $status = 'Pending';
                                        }elseif($d->status_py == 'Approve') {
                                            $btn_st = 'btn-success';
                                            $icn = 'fa-check-circle';
                                            $status = 'Aprrove';
                                        }elseif($d->status_py == 'Ditolak') {
                                            $btn_st = 'btn-danger';
                                            $icn = 'fa-times-circle';
                                            $status = 'Ditolak';
                                        }else{
                                            $btn_st = 'btn-secondary';
                                            $icn = 'fa-tag';
                                            $status = 'Pengajuan';
                                        }
                                    ?>
                                        <tr class="odd">
                                            <td><?= $no++ ?></td>
                                            <td>
                                                <button class="btn <?= $btn_st ?> btn-sm"><i class="fas <?= $icn ?>"></i> <?= $status ?></button>
                                                <?php if($d->status_py == 'Ditolak') : ?>
                                                    <?php if($user['role_id'] == '1' || $user['role_id'] == '5') : ?>
                                                        <button class="btn btn-info btn-sm view-btn" data-id="<?= $d->id_py ?>" data-toggle="modal" data-target="#viewAlasan"><i class="fas fa-eye"></i> Lihat Alasan</button>
                                                    <?php elseif ($user['role_id'] == '2' || $user['role_id'] == '3' || $user['role_id'] == '4') : ?>
                                                        <button class="btn btn-info btn-sm edit-alasan" data-id="<?= $d->id_py ?>" data-toggle="modal" data-target="#editAlasan"><i class="fas fa-eye"></i> Edit Alasan</button>
                                                    <?php endif; ?>
                                                <?php endif; ?>
                                            </td>
                                            <td><?= $d->nama_user ?></td>
                                            <td><?= $d->kegiatan ?></td>
                                            <td><?= 'Rp. ' . number_format($d->nominal, 0, ',', '.') ?></td>
                                            <td><?= mediumdate_indo($d->jadwal) ?></td>
                                            <td><?= mediumdate_indo($d->jatuh_tempo) ?></td>
                                            <td>
                                                <?php if(empty($d->status_py)) : ?>
                                                    <a href="<?= base_url('data_penyelesaian/penyelesaian?id='.$d->id_rk) ?>" class="btn btn-primary btn-xs"><i class="fa fa-edit"></i> Pengajuan</a>
                                                <?php elseif($d->status_py == 'Approve') : ?>
                                                    <a target="_blank" href="<?= base_url('penyelesaian/cetak?id='.$d->id_rk) ?>" class="btn btn-info btn-xs"><i class="fa fa-print"></i> Print</a>
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>

                                    </tbody>
                                </table>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>

