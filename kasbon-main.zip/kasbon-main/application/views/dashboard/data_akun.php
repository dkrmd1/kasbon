<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1>Data Akun</h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="<?= base_url(); ?>">Home</a></li>
                        <li class="breadcrumb-item active">Data Akun</li>
                    </ol>
                </div>
            </div>
        </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-4">

                    <!-- Profile Image -->
                    <div class="card card-primary card-outline">
                        <div class="card-body box-profile">
                            <div class="text-center">
                                <img class="profile-user-img img-fluid img-circle" src="<?= base_url('assets/'); ?>dist/img/avatar5.png"
                                    alt="User profile picture">
                            </div>

                            <h3 class="profile-username text-center"><?= $user['name'] ?></h3>

                            <ul class="list-group list-group-unbordered mb-3">
                                <li class="list-group-item">
                                    <b>Email</b> <a class="float-right"><?= $user['email'] ?></a>
                                </li>
                                <li class="list-group-item">
                                    <b>NIP</b> <a class="float-right"><?= $user['nip'] ?></a>
                                </li>
                                <br />
                                <button class="btn btn-primary btn-block" onclick="Logout();"><b><i class="fa fa-sign-out-alt"></i> Logout</b></button>
                            </ul>
                        </div>
                        <!-- /.card-body -->
                    </div>
                    <!-- /.card -->

                    
                    <!-- Profile Image -->
                    <div class="card card-primary card-outline">
                        <div class="card-body box-profile">
                            <div class="text-center">
                                <img class="img-fluid" width="300" src="<?= base_url('assets/img/ttd/'.$user['ttd']); ?>" alt="TTD">
                            </div>

                            <ul class="list-group list-group-unbordered mb-3">
                                <li class="list-group-item">
                                    <b>TTD</b> <a class="float-right"><?= $user['name'] ?></a>
                                </li>
                                <form method="post" action="<?= base_url('data_akun/ttd') ?>" enctype="multipart/form-data">
                                    <input type="hidden" id="id" name="id" value="<?= $user['id_user'] ?>">
                                    <div class="input-group mb-3">
                                        <div class="custom-file">
                                            <input type="file" class="custom-file-input" id="file" name="file">
                                            <label class="custom-file-label" for="file">Pilih file</label>
                                        </div>
                                    </div>
                                    <button type="submit" class="btn btn-primary btn-block"><b><i class="fa fa-redo"></i> Update TTD</b></button>
                                </form>
                            </ul>
                        </div>
                    </div>

                </div>
                <div class="col-md-8">

                    <div class="card card-primary card-tabs">
                        <div class="card-header p-0 pt-1">
                            <ul class="nav nav-tabs" id="custom-tabs-one-tab" role="tablist">
                                <li class="nav-item"><a class="nav-link active" href="#edit-akun" data-toggle="tab">Edit
                                        Akun</a></li>
                                <li class="nav-item"><a class="nav-link" href="#ganti-password" data-toggle="tab">Ganti
                                        Password</a></li>
                            </ul>
                        </div>


                        <div class="tab-content">
                            <div class="active tab-pane" id="edit-akun">

                                <!-- /.card-header -->

                                <div class="card-body">
                                    <form method="post" action="<?= base_url('data_akun/akun') ?>" enctype="multipart/form-data">
                                        <div class="form-group">
                                            <label>Nama Lengkap</label>
                                            <input type="text" class="form-control" id="nama" name="nama" placeholder="Nama Lengkap" value="<?= $user['name'] ?>" require>
                                            <input type="hidden" id="id" name="id" value="<?= $user['id_user'] ?>">
                                            <?= form_error('nama', '<small class="text-danger pl-3">', ' </small>') ?>
                                        </div>

                                        <div class="form-group">
                                            <label>NIP</label>
                                            <input type="number" class="form-control" id="nip" name="nip" placeholder="NIP" value="<?= $user['nip'] ?>" require>
                                            <?= form_error('nip', '<small class="text-danger pl-3">', ' </small>') ?>
                                        </div>

                                        <div class="form-group">
                                            <label>Email</label>
                                            <input type="email" class="form-control" id="email" name="email" placeholder="Email" value="<?= $user['email'] ?>" require>
                                            <?= form_error('email', '<small class="text-danger pl-3">', ' </small>') ?>
                                        </div>

                                        <div class="form-group">
                                            <label>Nomor Hp</label>
                                            <input type="number" class="form-control" id="no_hp" name="no_hp" placeholder="Nomor Telepon" value="<?= $user['no_hp'] ?>" require>
                                            <?= form_error('no_hp', '<small class="text-danger pl-3">', ' </small>') ?>
                                        </div>

                                        <button type="button" id="update" class="btn btn-primary btn-block"><i class="fa fa-redo"></i> Simpan Data</button>
                                        <input hidden type="submit" id="submit_u">
                                    </form>    
                                </div>

                            </div>


                            <div class="tab-pane" id="ganti-password">
                                <div class="card-body">

                                        <div class="form-group form-box">
                                            <label>Password </label>
                                            <div class="input-group" onchange="onChanges()">
                                                <div class="input-group-prepend">
                                                    <div onclick="myFunction()" class="input-group-text pointer"><i id="icon" class="fa fa-eye-slash"></i></div>
                                                </div>
                                                <input type="password" class="form-control active" onchange="onChanges()" id="password" name="password" placeholder="Password" value="" require>
                                            </div>
                                            <small class="text-danger font-13 pull-left font-weight-bold" ></small>
                                            
                                        </div>
                                        <div class="form-group form-box">
                                            <label>Password Baru</label>
                                            <input type="password" class="form-control" id="password_new<?= $user['id_user'] ?>" onchange="onChanges()" name="password_new" placeholder="Password baru" value="" require>
                                            <small class="text-danger font-13 pull-left font-weight-bold" ></small>
                                            
                                        </div>
                                        <div class="form-group form-box">
                                            <label>Ulangi Password Baru</label>
                                            <input type="password" class="form-control" id="password_ulang" name="password_ulang" placeholder="Ulangi password baru" value="" onchange="onChanges()" require>
                                            <small class="text-danger font-13 pull-left font-weight-bold" ></small>
                                            
                                        </div>
                                       
                                        <button id="submit" class="btn btn-primary btn-block" onclick="updatePassword('<?= $user['id_user'] ?>');"><b><i class="fa fa-redo"></i> Update Password</b></button>
                                </div>
                            </div>

                        </div>
                    </div>

                    <!-- /.card -->
                </div>
            </div>
        </div>
    </section>
</div>

<script type="text/javascript">
$("#update").on('click', function(){
    swal.fire({
            title: "Yakin ingin mengupdate data?",
            icon: "warning",
            showCancelButton: true,
            // confirmButtonColor: "#DC3545",
            confirmButtonText: "<i class='fa fa-check'></i> Simpan",
            cancelButtonText: "<i class='fa fa-times'></i> Batal",
            closeOnConfirm: false,
            closeOnCancel: false
        }).then(function (result) {
            if (result.value) {
                swal.fire({
                    title: "Tersimpan!",
                    text: 'Berhasil mengupdate data.',
                    icon: 'success',
                    confirmButtonText: "<i class='fa fa-thumbs-up'></i> Oke!",
                }).then(function(isConfirm) {
                    $('#submit_u').trigger('click');
                });
            } else {
                swal.fire({
                    title: "Membatalkan!",
                    icon: 'error',
                    confirmButtonText: '<i class="fa fa-thumbs-up"></i> Oke!',
                });
            }
        });
});
</script>

<script type="text/javascript">
function updatePassword(id) {

   if($('#password_new<?= $user['id_user'] ?>').val() == ''){
        Swal.fire({
            confirmButtonText: "<i class='fa fa-thumbs-up'></i> Oke!",
            icon: 'error',
            title: 'Gagal!',
            text: 'Kolom Password baru tidak boleh kosong.'
        })
   }else if($('#password_ulang').val() == ''){
        Swal.fire({
            confirmButtonText: "<i class='fa fa-thumbs-up'></i> Oke!",
            icon: 'error',
            title: 'Gagal!',
            text: 'Kolom Ulangi password baru tidak boleh kosong.'
        })
   }else if($('#password_new<?= $user['id_user'] ?>').val() !== $('#password_ulang').val()){
        Swal.fire({
            confirmButtonText: "<i class='fa fa-thumbs-up'></i> Oke!",
            icon: 'error',
            title: 'Gagal!',
            text: 'Password tidak sama.'
        })
   }else{

        var password = $('#password').val();
        var email = $('#email').val();
        var password_new = $('#password_new' + id).val();
        var password_ulang = $('#password_ulang').val();
                
        var valid = false;
        $.ajax({
            url: "<?= base_url('get/get_password'); ?>",
            type: "POST",
            data: {"id": id, "password":password},
            dataType: "text",
                success: function(data){
                    if (data==1){ 
                        Swal.fire({
                            confirmButtonText: "<i class='fa fa-thumbs-up'></i> Oke!",
                            icon: 'error',
                            title: 'Gagal!',
                            text: 'Password lama tidak sesuai.'
                        })
                    }else{
                        $.ajax({
                            url: "<?= base_url('data_akun/password'); ?>",
                            method: "POST",
                            data: {"id": id, "password_ulang":password_ulang},
                            success: function (data) {
                                Swal.fire({
                                    confirmButtonText: "<i class='fa fa-thumbs-up'></i> Oke!",
                                    icon: 'success',
                                    title: 'Terupdate!',
                                    text: 'Data password berhasil di update.'
                                }).then(function(isConfirm) {
                                    window.location.href = "<?= base_url('auth/logout') ?>";
                                });
                            }
                        });

                    }
                }
        });  
    }
}
</script>

<script type="text/javascript">
var input = document.getElementById('password'),
    icon = document.getElementById('icon');

icon.onclick = function() {

    if (input.className == 'active form-control') {
        input.setAttribute('type', 'password');
        icon.className = 'fa fa-eye-slash';
        input.className = 'form-control';

    } else {
        input.setAttribute('type', 'text');
        icon.className = 'fa fa-eye';
        input.className = 'active form-control';
    }

}
</script>
<script type="text/javascript">
$(document).on("click", ".browse", function() {
    var file = $(this).parents().find(".file");
    file.trigger("click");
});

$('#imgInp').change(function(e) {
    var fileName = e.target.files[0].name;
    $("#file").val(fileName);

    var reader = new FileReader();
    reader.onload = function(e) {
        // get loaded data and render thumbnail.
        document.getElementById("preview").src = e.target.result;
    };
    // read the image file as a data URL.
    reader.readAsDataURL(this.files[0]);
});
</script>