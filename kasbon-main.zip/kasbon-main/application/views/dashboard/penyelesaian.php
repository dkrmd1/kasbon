<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1>RENCANA KEGIATAN</h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="<?= base_url(); ?>">Home</a></li>
                        <li class="breadcrumb-item active">Rencana Kegiatan</li>
                    </ol>
                </div>
            </div>
        </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">

                    <form method="post" action="<?= base_url('data_penyelesaian/save') ?>" enctype="multipart/form-data">
                        <input type="hidden" class="form-control" id="id_rk" name="id_rk" value="<?= $data->id_rk ?>">
                        <div class="card">
                            <div class="card-header">
                                <h3 class="card-title text-bold">Yang bertandatangan dibawah ini :</h3>
                                <div class="card-tools">
                                    <button type="button" class="btn btn-tool" data-card-widget="collapse">
                                        <i class="fas fa-minus"></i>
                                    </button>
                                </div>
                            </div>
                            <!-- /.card-header -->

                            <div class="card-body"> 
                                <div class="row">
                                    <div class="col-lg-6 col-md-6">
                                        <div class="form-group row">
                                            <label class="col-sm-2 col-form-label">Nama</label>
                                            <div class="col-sm-10">
                                                <input type="text" class="form-control" id="nama" name="nama" value="<?= $data->nama_user ?>" disabled>
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-sm-2 col-form-label">Jabatan</label>
                                            <div class="col-sm-10">
                                                <input type="text" class="form-control" id="jabatan" name="jabatan" value="<?= $data->jabatan_user ?>" disabled>
                                            </div>
                                        </div>
                                    </div>
                                
                                </div>
                            </div>
                        </div>


                        <div class="card">
                            <div class="card-header">
                                <h3 class="card-title text-bold">Dengan ini menerangkan bahwa akan melaksanakan kegiatan data sbb:</h3>
                                <div class="card-tools">
                                    <button type="button" class="btn btn-tool" data-card-widget="collapse">
                                        <i class="fas fa-minus"></i>
                                    </button>
                                </div>
                            </div>
                            <!-- /.card-header -->

                            <div class="card-body"> 
                                <div class="row">
                                    <div class="col-lg-6 col-md-6">
                                        <div class="form-group row">
                                            <label class="col-sm-2 col-form-label">Kegiatan</label>
                                            <div class="col-sm-10">
                                                <input type="text" class="form-control" id="kegiatan" name="kegiatan" placeholder="Nama Kegiatan" value="<?= $data->kegiatan ?>" disabled>
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-sm-2 col-form-label">Tempat</label>
                                            <div class="col-sm-10">
                                                <input type="text" class="form-control" id="tempat" name="tempat" placeholder="Tempat" value="<?= $data->tempat ?>" disabled>
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-sm-3 col-form-label">Jadwal Kegiatan</label>
                                            <div class="col-sm-9">
                                                <div class="input-group">
                                                    <input type="text" class="form-control" id="jadwal" name="jadwal" value="<?= mediumdate_indo($data->jadwal) ?>" disabled/>
                                                    <div class="input-group-append" data-target="#reservationdate" data-toggle="datetimepicker">
                                                        <div class="input-group-text"><i class="fa fa-calendar"></i></div>
                                                    </div>
                                                </div>
                                        </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-sm-2 col-form-label">Biaya</label>
                                            <div class="col-sm-10">
                                                <input type="text" class="form-control" id="biaya" name="biaya" placeholder="Perkiraan Biaya" value="<?= $data->biaya ?>" disabled>
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-sm-2 col-form-label">Jatuh Tempo</label>
                                            <div class="col-sm-10">
                                                <div class="input-group">
                                                    <input type="text" class="form-control datetimepicker-input" id="jatuh_tempo" name="jatuh_tempo" value="<?= $data->jatuh_tempo ?>" disabled/>
                                                    <div class="input-group-append" data-toggle="datetimepicker">
                                                        <div class="input-group-text"><i class="fa fa-calendar"></i></div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                               

                                    </div>

                                </div>
                            </div>
                        </div>
                        
                        <div class="card">
                            <div class="card-header">
                                <h3 class="card-title text-bold">Sehubungan dengan hal tersebut, dengan ini mohon persetujuan Bapak/ibu untuk mengajukan Penggunaan Uang Muka sebesar :</h3>
                                <div class="card-tools">
                                    <button type="button" class="btn btn-tool" data-card-widget="collapse">
                                        <i class="fas fa-minus"></i>
                                    </button>
                                </div>
                            </div>
                            <div class="card-body"> 
                                <div class="row">
                                    <div class="col-lg-6 col-md-6">
                                        <div class="form-group row">
                                            <label class="col-sm-2 col-form-label">Nominal</label>
                                            <div class="col-sm-10">
                                                <input type="text" class="form-control" id="nominal" name="nominal" placeholder="Nominal"  value="<?= $data->nominal ?>" disabled>
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-sm-2 col-form-label">Terbilang</label>
                                            <div class="col-sm-10">
                                                <input type="text" class="form-control" id="terbilang" name="terbilang" placeholder="Terbilang" value="<?= $data->terbilang ?>" disabled>
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-sm-3 col-form-label">Penandatangan</label>
                                            <div class="col-sm-9">
                                                <select class="form-control select2" style="width: 100%" id="ttd_py" name="ttd_py">
                                                    <option value="">--Pilih Orang--</option>
                                                    <?php foreach($data_user as $d) : ?>
                                                    <option value="<?= $d->id_user ?>"><?= $d->name ?></option>
                                                    <?php endforeach; ?>
                                                </select>
                                            </div>
                                        </div>
                            </div>
                        </div>

                        <div class="card mt-5">
                            <div class="card-header">
                                <h3 class="card-title text-bold">Rincian Penggunaan Uang Muka</h3>
                                <div class="card-tools">
                                    <button type="button" class="btn btn-tool" data-card-widget="collapse">
                                        <i class="fas fa-minus"></i>
                                    </button>
                                </div>
                            </div>
                            <div class="card-body"> 
                                    <div class="row">
                                        <div class="col-lg-12 col-md-12">
                                            <textarea id="summernote" name="rincian"></textarea>
                                        </div>
                                    </div>
                            </div>
                        </div>

                        <div class="card">
                            <div class="card-footer">
                                <button class="btn btn-block btn-primary" type="button" id="simpan"><i class="fa fa-check"></i> Simpan Data</button>
                                <input hidden type="submit" id="submit">
                            </div>
                        </div>
                    </form>

                </div>

            </div>
        </div>
    </section>
</div>

<script type="text/javascript">

$("#simpan").on('click', function(){
    var ttd_py   = $("#ttd_py").val();

    if(ttd_py == ''){
        Swal.fire({
                confirmButtonText: "<i class='fa fa-thumbs-up'></i> Oke!",
                icon: 'warning',
                title: 'Oops!',
                text: 'Data belum lengkap.'
        });
            die;
    } else {

        swal.fire({
            title: "Yakin ingin menyimpan data?",
            icon: "info",
            showCancelButton: true,
            // confirmButtonColor: "#DC3545",
            confirmButtonText: "<i class='fa fa-check'></i> Simpan",
            cancelButtonText: "<i class='fa fa-times'></i> Batal",
            closeOnConfirm: false,
            closeOnCancel: false
        }).then(function (result) {
            if (result.value) {
                swal.fire({
                    title: "Tersimpan!",
                    text: 'Berhasil menyimpan data.',
                    icon: 'success',
                    confirmButtonText: "<i class='fa fa-thumbs-up'></i> Oke!",
                }).then(function(isConfirm) {
                    $('#submit').trigger('click');
                });
            } else {
                swal.fire({
                    title: "Membatalkan!",
                    icon: 'error',
                    confirmButtonText: '<i class="fa fa-thumbs-up"></i> Oke!',
                });
            }
        });
    }
});
</script>