<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1>Tambah User</h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="<?= base_url(); ?>">Home</a></li>
                        <li class="breadcrumb-item active">Tambah User</li>
                    </ol>
                </div>
            </div>
        </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">

                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">Tambah User</h3>
                            <div class="card-tools">
                                <a href="<?= base_url('data_user') ?>" class="btn btn-primary"><i class="fa fa-list"></i> Data User</a>
                            </div>
                        </div>
                        <!-- /.card-header -->

                        <form method="post" action="<?= base_url('data_user/save_user') ?>" enctype="multipart/form-data">

                            <div class="card-body"> 

                                <div class="row">
                                    <div class="col-lg-6 col-md-6">

                                        <div class="form-group">
                                            <label>Nama Lengkap</label>
                                            <input type="text" class="form-control" id="nama" name="nama" placeholder="Nama Lengkap" require>
                                        </div>

                                        <div class="form-group">
                                            <label>NIP</label>
                                            <input type="number" class="form-control" id="nip" name="nip" placeholder="NIP" require>
                                        </div>

                                        <div class="form-group">
                                            <label>Email</label>
                                            <input type="text" class="form-control" id="email" name="email"
                                                placeholder="Email" value="<?= set_value('email') ?>" require>
                                            <?= form_error('email', '<small class="text-danger pl-3">', ' </small>') ?>
                                        </div>

                                        <div class="form-group form-box">
                                            <label>Password </label>
                                            <div class="input-group">
                                                <div class="input-group-prepend">
                                                    <div onclick="myFunction()" class="input-group-text pointer"><i id="icon" class="fa fa-eye"></i></div>
                                                </div>
                                                <input type="text" class="active form-control" id="password" name="password" placeholder="Password" require>
                                            </div>
                                        </div>

                                        <div class="form-group">
                                            <label>Nomor Hp</label>
                                            <input type="number" class="form-control" id="no_hp" name="no_hp" placeholder="Nomor Telepon" require>
                                        </div>
                                    </div>

                                    <div class="col-lg-6 col-md-6">

                                        <div class="form-group">
                                            <label>Jabatan</label>
                                            <input type="text" class="form-control" id="jabatan" name="jabatan" placeholder="Jabatan" require>
                                        </div>
                                        <div class="form-group">
                                            <label>Divisi</label>
                                            <a href="<?= base_url('data_divisi') ?>" class="badge badge-success">Tambah</a>
                                            <select class="form-control" id="divisi" name="divisi">
                                                <option value="" selected>--Pilih Divisi--</option>
                                                <?php foreach($data_divisi as $d) : ?>
                                                <option value="<?= $d->id_divisi ?>"><?= $d->divisi ?></option>
                                                <?php endforeach; ?>
                                            </select>
                                        </div>

                                        <div class="form-group">
                                            <label>Role User</label>
                                            <select class="form-control" id="role" name="role">
                                                <option value="" selected>- Pilih Role -</option>
                                                <?php if($user['role_id'] == '1') : ?>
                                                <option value="1">Admin</option>
                                                <option value="2">Direktur Utama</option>
                                                <?php endif; ?>
                                                <option value="3">Direksi</option>
                                                <option value="4">Group Head</option>
                                                <option value="5">Staff</option>
                                            </select>
                                        </div>

                                        <div class="form-group">
                                            <label>Status</label>
                                            <select class="form-control" id="status" name="status">
                                                <option value="on" selected>Aktif</option>
                                                <option value="off">Tidak Aktif</option>
                                            </select>
                                        </div>

                                    </div>

                                </div>
                            </div>

                            <div class="card-footer">
                                <button class="btn btn-primary" type="button" id="simpan"><i class="fa fa-check"></i> Simpan Data</button>
                                <input hidden type="submit" id="submit">
                            </div>
                        </form>
                    </div>

                </div>

            </div>
        </div>
    </section>
</div>

<script type="text/javascript">
$("#simpan").on('click', function(){
    var nama   = $("#nama").val();
    var nip   = $("#nip").val();
    var email   = $("#email").val();
    var password   = $("#password").val();
    var jabatan   = $("#jabatan").val();
    var role   = $("#role").val();

    if(nama =='' || email =='' || password =='' || no_hp =='' || nip =='' || jabatan =='' || role ==''){
        Swal.fire({
                confirmButtonText: "<i class='fa fa-thumbs-up'></i> Oke!",
                icon: 'warning',
                title: 'Oops!',
                text: 'Data belum lengkap.'
        });
            die;
    } else {
         
    $.ajax({
            url: "<?= base_url('get/get_email'); ?>",
            type: "POST",
            data: {"email":email},
            dataType: "text",
                success: function(data){
                    if (data==1){ 
                        Swal.fire({
                            confirmButtonText: "<i class='fa fa-thumbs-up'></i> Oke!",
                            icon: 'warning',
                            title: 'Oops!',
                            text: 'Email ini sudah di gunakan.'
                        })
                    }
                }
        });

    swal.fire({
            title: "Yakin ingin menyimpan data?",
            icon: "info",
            showCancelButton: true,
            // confirmButtonColor: "#DC3545",
            confirmButtonText: "<i class='fa fa-check'></i> Simpan",
            cancelButtonText: "<i class='fa fa-times'></i> Batal",
            closeOnConfirm: false,
            closeOnCancel: false
        }).then(function (result) {
            if (result.value) {
                swal.fire({
                    title: "Tersimpan!",
                    text: 'Berhasil menyimpan data.',
                    icon: 'success',
                    confirmButtonText: "<i class='fa fa-thumbs-up'></i> Oke!",
                }).then(function(isConfirm) {
                    $('#submit').trigger('click');
                });
            } else {
                swal.fire({
                    title: "Membatalkan!",
                    icon: 'error',
                    confirmButtonText: '<i class="fa fa-thumbs-up"></i> Oke!',
                });
            }
        });
    }
});

</script>

<script type="text/javascript">
var input = document.getElementById('password'),
    icon = document.getElementById('icon');

icon.onclick = function() {

    if (input.className == 'active form-control') {
        input.setAttribute('type', 'text');
        icon.className = 'fa fa-eye';
        input.className = 'form-control';

    } else {
        input.setAttribute('type', 'password');
        icon.className = 'fa fa-eye-slash';
        input.className = 'active form-control';
    }

}
</script>