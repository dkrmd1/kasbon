<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Rencana_kegiatan extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
           // Periksa apakah sesi login aktif
           is_logged_in();
           $this->load->model('Main_model');
    }

    public function index()
    {
        $data['title'] = "Rencana Kegiatan";
        $data['user'] = sess_user();

        $data['data_user'] = $this->db->get_where('user', [
            'role_id !=' => '5',
            'divisi_id' => $data['user']['divisi_id']
            ])->result();

        $this->load->view('template/header_tabel', $data);
        $this->load->view('template/navbar', $data);
        $this->load->view('dashboard/rencana_kegiatan', $data);
        $this->load->view('template/footer_kasbon');
    }

    public function data()
    {
        $data['title'] = "Data Uang Muka";
        $data['user'] = sess_user();

        $params = [];
        if($data['user']['role_id'] == '2' || $data['user']['role_id'] == '3' || $data['user']['role_id'] == '4'){
            if($data['user']['divisi_id'] == '1'){
                $params['status_fin'] = ['Pending', 'Approve', 'Ditolak'];
            }else{
                $params['divisi_id'] = $data['user']['divisi_id'];
            }
        }
        if($data['user']['role_id'] == '5'){
            $params['id_user'] = $data['user']['id_user'];
        }
        $this->db->order_by('tbl_rk.id_rk', 'desc');
        $data['data'] = $this->Main_model->get_rk($params);

        $this->load->view('template/header_tabel', $data);
        $this->load->view('template/navbar', $data);
        $this->load->view('dashboard/data/rencana_kegiatan', $data);
        $this->load->view('template/footer_tabel');
    }
    
    public function save()
    {
        $user = sess_user();
        $data = [
            'id_user' => $user['id_user'],
            'divisi_id' => $user['divisi_id'],
            'tgl_rk' => date('Y-m-d'),
            'kegiatan' => $this->input->post('kegiatan'),
            'tempat' => $this->input->post('tempat'),
            'jadwal' => $this->input->post('jadwal'),
            'jatuh_tempo' => $this->input->post('jatuh_tempo'),
            'biaya' => $this->input->post('biaya'),
            'nominal' => $this->input->post('biaya'),
            'terbilang' => $this->input->post('terbilang'),
            'penandatangan' => $this->input->post('penandatangan'),
            'status' => 'Pending',
            'approval' => 'Pending',
        ];
        $this->db->insert('tbl_rk', $data);

        $this->session->set_flashdata('message', '<div class="alert alert-success alert-dismissible fade show" role="alert">
        <strong>Success!</strong> Berhasil menambahkan data!
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">&times;</span></button></div>');
        redirect('rencana_kegiatan/data');
    }
    
    public function update()
    {
        $data['title'] = "Edit Rencana Kegiatan";
        $data['user'] = sess_user();

        $params['id_rk'] = $this->input->get('id');
        $data['data'] = $this->Main_model->get_rk($params);
        if(!$data['data']){
            redirect('rencana_kegiatan/data');
        }

        $this->form_validation->set_rules('kegiatan', 'Kegiatan', 'required');
        if ($this->form_validation->run() == false) {
            $this->load->view('template/header_tabel', $data);
            $this->load->view('template/navbar', $data);
            $this->load->view('dashboard/edit/rencana_kegiatan', $data);
            $this->load->view('template/footer_kasbon');
        }else{
            $id = $this->input->post('id_rk');
            $data = [
                'kegiatan' => $this->input->post('kegiatan'),
                'tempat' => $this->input->post('tempat'),
                'jadwal' => $this->input->post('jadwal'),
                'jatuh_tempo' => $this->input->post('jatuh_tempo'),
                'biaya' => $this->input->post('biaya'),
                'nominal' => $this->input->post('biaya'),
                'terbilang' => $this->input->post('terbilang'),
            ];
            $this->db->where('id_rk', $id);
            $this->db->update('tbl_rk', $data);

            $this->session->set_flashdata('message', '<div class="alert alert-success alert-dismissible fade show" role="alert">
            <strong>Success!</strong> Berhasil mengupdate data!
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span></button></div>');
            redirect('rencana_kegiatan/update?id='.$id);
        }
    }

    public function edit_alasan() {
        $id = $this->input->post('id');
        $this->db->set([
            'alasan' => $this->input->post('alasan')
        ]);
        $this->db->where('id_rk', $id);
        $this->db->update('tbl_rk');
        
        $this->session->set_flashdata('message', '<div class="alert alert-success alert-dismissible fade show" role="alert">
        <strong>Success!</strong> Alasan penolakan berhaasil diupdate!
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">&times;</span></button></div>');
        redirect('rencana_kegiatan/data');
    }

    public function approve() {
        $user = sess_user();
        if ($this->input->is_ajax_request()) {
            $id = $this->input->post('id');

            if($data['user']['divisi_id'] == '1'){
                $status = 'Approve';
                $approval = 'FIN';
            }else{
                $status = 'Pending';
                $approval = 'GH';
            }

            $this->db->set([
                'ttd'       => $user['id_user'],
                'alasan'    => NULL,
                'status'    => $status, 
                'approval'  => $approval, 
                'tgl_persetujuan' => date('Y-m-d')
            ]);
            $this->db->where('id_rk', $id);
            $this->db->update('tbl_rk');
        }
    }

    public function approve_fin() {
        $user = sess_user();
        if ($this->input->is_ajax_request()) {
            $id = $this->input->post('id');

            $this->db->set([
                'approval' => 'FIN',
                'status_fin'    => 'Approve',
            ]);
            $this->db->where('id_rk', $id);
            $this->db->update('tbl_rk');
        }
    }

    public function ditolak() {
        $id = $this->input->post('id');
        $this->db->set([
            'alasan'    => $this->input->post('alasan'),
            'status'    => 'Ditolak',
            'approval' => 'GH',
            'tgl_persetujuan' => NULL
        ]);
        $this->db->where('id_rk', $id);
        $this->db->update('tbl_rk');
        
        $this->session->set_flashdata('message', '<div class="alert alert-success alert-dismissible fade show" role="alert">
        <strong>Success!</strong> Penolakan data berhasil!
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">&times;</span></button></div>');
        redirect('rencana_kegiatan/data');
    }

    
    public function cetak()
    {
        $data['title'] = "Cetak Rencana Kegiatan";
        $data['user'] = sess_user();

        $params['id_rk'] = $this->input->get('id');
        $data['data'] = $this->Main_model->get_rk($params);
        $data['per'] = $this->db->get_where("tbl_perusahaan", ["id_perusahaan" => '1'])->row();

        $this->load->view('cetak/rencana_kegiatan', $data);
        $this->load->view('cetak/bukti_penerimaan', $data);
    }

    
    public function teruskan() {
        if ($this->input->is_ajax_request()) {
            $id = $this->input->post('id');
            $this->db->set([
                'status_fin'    => 'Pending',
            ]);
            $this->db->where('id_rk', $id);
            $this->db->update('tbl_rk');
        }
    }

    
    public function hapus() {
        if ($this->input->is_ajax_request()) {
            $id = $this->input->post('id');
            $this->db->where('id_rk', $id);
            $this->db->delete('tbl_rk');
        }
    }

}
