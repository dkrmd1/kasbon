<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Data_divisi extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        is_logged_in();
        $user = sess_user();
        if ($user['role_id'] !== '1') {
            redirect('dashboard');
        }
    }

    public function index()
    {
        $data['title'] = "Data Group";
        $data['user'] = sess_user();

        $data['data'] = $this->db->get('tbl_divisi')->result();

        $this->load->view('template/header_tabel', $data);
        $this->load->view('template/navbar', $data);
        $this->load->view('dashboard/data_divisi', $data);
        $this->load->view('template/footer_tabel');
    }

    public function tambah_divisi()
    {
        $divisi = $this->input->post('divisi');
        $cek_data = $this->db->get_where('tbl_divisi', "divisi='$divisi'")->num_rows();
        if ($cek_data == 0) {
            $data = [
                'divisi' => $divisi,
                'kode_divisi' => $this->input->post('kode_divisi'),
            ];
            $this->db->insert('tbl_divisi', $data);
        }else{
            $this->session->set_flashdata('message', '<div class="alert alert-danger alert-dismissible fade show" role="alert">
            <strong>Opss!</strong> Data yang anda input sudah ada!
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span></button></div>');
            redirect('data_divisi');
        }

        $this->session->set_flashdata('message', '<div class="alert alert-success alert-dismissible fade show" role="alert">
        <strong>Success!</strong> Berhasil menambahkan data!
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">&times;</span></button></div>');
        redirect('data_divisi');
    }

    public function update_divisi()
    {
        $id = $this->input->post('id');

        $data = [
            'divisi' => $this->input->post('divisi'),
            'kode_divisi' => $this->input->post('kode_divisi'),
        ];
        $this->db->where('id_divisi', $id);
        $this->db->update('tbl_divisi', $data);

        $this->session->set_flashdata('message', '<div class="alert alert-success alert-dismissible fade show" role="alert">
        <strong>Success!</strong> Data berhasil diupdate!
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">&times;</span></button></div>');
        redirect('data_divisi');
    }
    
    
    public function hapus() {
        if ($this->input->is_ajax_request()) {
            $id = $this->input->post('id');
            $this->db->where('id_divisi', $id);
            $this->db->delete('tbl_divisi');
        }
    }

}
