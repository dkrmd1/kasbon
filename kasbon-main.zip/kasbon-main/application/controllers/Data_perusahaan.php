<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Data_perusahaan extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
           // Periksa apakah sesi login aktif
           is_logged_in();
    }
    

    public function index()
    {
        $data['title'] = "Data Perusahaan";
        $data['user'] = sess_user();

        $data['data'] =  $this->db->get_where('tbl_perusahaan', ['id_perusahaan' => '1'])->row();

        $this->form_validation->set_rules('nama', 'Nama Perusahaan', 'required');
        $this->form_validation->set_rules('alamat', 'Alamat Perusahaan', 'required');
        if ($this->form_validation->run() == false) {
            $this->load->view('template/header_tabel', $data);
            $this->load->view('template/navbar', $data);
            $this->load->view('dashboard/data_perusahaan', $data);
            $this->load->view('template/footer_kasbon');
        }else{
            $id = $this->input->post('id_perusahaan');

            $config['upload_path']   = './assets/img/logo/';
            $config['allowed_types'] = 'png|PNG';
            $config['max_size']      = 8192; // 8MB max
            $config['encrypt_name']  = TRUE;
            $config['remove_space'] = TRUE;
            $this->load->library('upload', $config);
            $this->upload->initialize($config);

            if ($this->upload->do_upload('logo')) {
                $data_per = $this->db->get_where('tbl_perusahaan', "id_perusahaan='$id'")->row();
                $logo = $this->upload->data('file_name');
                unlink('./assets/img/logo/' . $data_per->logo);
            }else{
                $logo = $this->input->post('logo');
            }
            $data = [
                'nama' => $this->input->post('nama'),
                'alamat' => $this->input->post('alamat'),
                'logo' => $logo
            ];
            $this->db->where('id_perusahaan', $id);
            $this->db->update('tbl_perusahaan', $data);

            $this->session->set_flashdata('message', '<div class="alert alert-success alert-dismissible fade show" role="alert">
            <strong>Success!</strong> Berhasil mengupdate data!
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span></button></div>');
            redirect('data_perusahaan');
        }
    }

}
