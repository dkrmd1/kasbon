<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Data_user extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        // Periksa apakah sesi login aktif
        is_logged_in();
        $this->load->model('Main_model');
        $user = sess_user();
        if ($user['role_id'] !== '1') {
            redirect('dashboard');
        }
    }

    public function index()
    {
        $data['title'] = "Data User";
        $data['user'] = sess_user();

        $params['role'] = $this->input->get('role');
        $data['data'] = $this->Main_model->get_user($params);

        $this->load->view('template/header_tabel', $data);
        $this->load->view('template/navbar', $data);
        $this->load->view('dashboard/data_user', $data);
        $this->load->view('template/footer_tabel');
    }

    public function tambah_user()
    {
        $data['title'] = "Tambah User";
        $data['user'] = sess_user();

        $data['data_divisi'] = $this->db->get('tbl_divisi')->result();

        $this->load->view('template/header_tabel', $data);
        $this->load->view('template/navbar', $data);
        $this->load->view('dashboard/tambah_user', $data);
        $this->load->view('template/footer_tabel');
     
    }

    public function edit_user($id)
    {
        $data['title'] = "Edit User";
        $data['user'] = sess_user();

        $data['data'] = $this->db->get_where('user', ['id_user' => $id])->row_array();
        $data['data_divisi'] = $this->db->get('tbl_divisi')->result();

        $this->load->view('template/header_tabel', $data);
        $this->load->view('template/navbar', $data);
        $this->load->view('dashboard/edit_user', $data);
        $this->load->view('template/footer_tabel');
     
    }

    public function save_user()
    {
        $data = [
            'name' => $this->input->post('nama'),
            'nip' => $this->input->post('nip'),
            'email' => $this->input->post('email'),
            'password' => password_hash($this->input->post('password'), PASSWORD_DEFAULT),
            'no_hp' => $this->input->post('no_hp'),
            'jabatan' => $this->input->post('jabatan'),
            'divisi_id' => $this->input->post('divisi'),
            'role_id' => $this->input->post('role'),
            'status' => $this->input->post('status'),
            'date' => date('Y-m-d')
        ];
        $this->db->insert('user', $data);

        $this->session->set_flashdata('message', '<div class="alert alert-success alert-dismissible fade show" role="alert">
        <strong>Success!</strong> Berhasil menambahkan data!
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">&times;</span></button></div>');
        redirect('data_user');
    }

    public function update_user()
    {
        $id = $this->input->post('id');
        $password = $this->input->post('password');

        $cek_pass = $this->db->get_where('user', ['id_user' => $id])->row_array();

        if (empty($password)) {
            $pass = $cek_pass['password'];
        } else {
            $pass = password_hash($password, PASSWORD_DEFAULT);
        }
        $data = [
            'name' => $this->input->post('nama'),
            'nip' => $this->input->post('nip'),
            'email' => $this->input->post('email'),
            'password' => $pass,
            'no_hp' => $this->input->post('no_hp'),
            'jabatan' => $this->input->post('jabatan'),
            'divisi_id' => $this->input->post('divisi'),
            'role_id' => $this->input->post('role'),
            'status' => $this->input->post('status')
        ];
        $this->db->where('id_user', $id);
        $this->db->update('user', $data);

        $this->session->set_flashdata('message', '<div class="alert alert-success alert-dismissible fade show" role="alert">
        <strong>Success!</strong> Data berhasil diupdate!
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">&times;</span></button></div>');
        redirect('data_user/edit_user/' . $id);
    }
    
    
    public function hapus() {
        if ($this->input->is_ajax_request()) {
            $id = $this->input->post('id');
            $this->db->where('id_user', $id);
            $this->db->delete('user');
        }
    }

}
