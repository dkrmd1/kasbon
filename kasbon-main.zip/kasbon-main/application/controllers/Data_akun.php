<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Data_akun extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
           // Periksa apakah sesi login aktif
           is_logged_in();
    }
    

    public function index()
    {
        $data['title'] = "Data Akun";
        $data['user'] = sess_user();

        $data['data'] = $this->db->get('user')->result();

        $this->load->view('template/header_tabel', $data);
        $this->load->view('template/navbar', $data);
        $this->load->view('dashboard/data_akun', $data);
        $this->load->view('template/footer_tabel');
    }
    
    public function akun()
    {
        $id   = $this->input->post('id');
        $data = [
            'name' => $this->input->post('nama'),
            'nip' => $this->input->post('nip'),
            'email' => $this->input->post('email'),
            'no_hp' => $this->input->post('no_hp')
        ];

        $this->db->where('id_user', $id);
        $this->db->update('user', $data);
        redirect('data_akun');
    }

    
    public function ttd()
    {
        $id = $this->input->post('id');

        $config['upload_path']   = './assets/img/ttd/';
        $config['allowed_types'] = 'png|PNG';
        $config['max_size']      = 8192; // 8MB max
        $config['encrypt_name']  = TRUE;
        $config['remove_space'] = TRUE;
        $this->load->library('upload', $config);
        $this->upload->initialize($config);

        $data_user = $this->db->get_where('user', "id_user='$id'")->row();
        
        if ($this->upload->do_upload('file')) {
            $nama = $this->upload->data('file_name');
            $this->db->set('ttd', $nama);
            $this->db->where('id_user', $id);
            $this->db->update('user');

            if($data_user->ttd){
                unlink('./assets/img/ttd/' . $data_user->ttd);
            }

            $this->session->set_flashdata('message', '<div class="alert alert-success alert-dismissible fade show" role="alert">
            <strong>Success!</strong> Berhasil mengupdate data tanda tangan!
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span></button></div>');
            redirect('data_akun');
        }else{
            $this->session->set_flashdata('message', '<div class="alert alert-danger alert-dismissible fade show" role="alert">
            <strong>Oops!</strong> Gagal mengupdate data tanda tangan!
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span></button></div>');
            redirect('data_akun');
        }
    }

    public function password()
    {
        if ($this->input->is_ajax_request()) {
            $id = $this->input->post('id');
            $data = [
                'password' => password_hash($this->input->post('password_ulang'), PASSWORD_DEFAULT),
            ];
            $this->db->where('id_user', $id);
            $this->db->update('user', $data);
        }
    }

}
