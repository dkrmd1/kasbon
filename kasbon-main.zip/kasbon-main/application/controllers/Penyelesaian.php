<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Penyelesaian extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
           // Periksa apakah sesi login aktif
           is_logged_in();
           $this->load->model('Main_model');
    }

    public function index()
    {
        $data['title'] = "Penyelesaian";
        $data['user'] = sess_user();

        $data['data_user'] = $this->db->get_where('user', [
            'role_id !=' => '5',
            'divisi_id' => $data['user']['divisi_id']
            ])->result();

        $this->load->view('template/header_tabel', $data);
        $this->load->view('template/navbar', $data);
        $this->load->view('dashboard/penyelesaian', $data);
        $this->load->view('template/footer_kasbon');
    }
    
    public function data()
    {
        $data['title'] = "Data Penyelesaian";
        $data['user'] = sess_user();

        $params = [];
        if($data['user']['role_id'] == '2' || $data['user']['role_id'] == '3' || $data['user']['role_id'] == '4'){
            $params['divisi_id'] = $data['user']['divisi_id'];
        }
        if($data['user']['role_id'] == '5'){
            $params['id_user'] = $data['user']['id_user'];
        }
        $params['status_py'] = ['Pending', 'Approve', 'Ditolak'];
        $this->db->order_by('tbl_rk.id_rk', 'desc');
        $data['data'] = $this->Main_model->get_rk($params);

        $this->load->view('template/header_tabel', $data);
        $this->load->view('template/navbar', $data);
        $this->load->view('dashboard/data/penyelesaian', $data);
        $this->load->view('template/footer_tabel');
    }

    public function edit_alasan() {
        $id = $this->input->post('id');
        $this->db->set([
            'alasan_py' => $this->input->post('alasan')
        ]);
        $this->db->where('id_rk', $id);
        $this->db->update('tbl_rk');
        
        $this->session->set_flashdata('message', '<div class="alert alert-success alert-dismissible fade show" role="alert">
        <strong>Success!</strong> Alasan penolakan berhaasil diupdate!
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">&times;</span></button></div>');
        redirect('penyelesaian/data');
    }

    public function approve() {
        $user = sess_user();
        if ($this->input->is_ajax_request()) {
            $id = $this->input->post('id');
            $this->db->set([
                'ttd_py' => $user['id_user'],
                'alasan_py' => NULL,
                'status_py' => 'Approve',
            ]);
            $this->db->where('id_rk', $id);
            $this->db->update('tbl_rk');
        }
    }

    public function ditolak() {
        $id = $this->input->post('id');
        $this->db->set([
            'alasan_py' => $this->input->post('alasan'),
            'status_py' => 'Ditolak',
        ]);
        $this->db->where('id_rk', $id);
        $this->db->update('tbl_rk');
        
        $this->session->set_flashdata('message', '<div class="alert alert-success alert-dismissible fade show" role="alert">
        <strong>Success!</strong> Penolakan data berhasil!
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">&times;</span></button></div>');
        redirect('penyelesaian/data');
    }


    public function detail()
    {
        $data['title'] = "Detail Uang Muka";
        $data['user'] = sess_user();

        $params['id_rk'] = $this->input->get('id');
        $data['data'] = $this->Main_model->get_rk($params);

        if(!$data['data']){
            redirect('penyelesaian/data');
        }

        $this->load->view('template/header_tabel', $data);
        $this->load->view('template/navbar', $data);
        $this->load->view('dashboard/detail_uangmuka', $data);
        $this->load->view('template/footer_kasbon');
    }
    
    public function cetak()
    {
        $data['title'] = "Cetak Rencana Kegiatan";
        $data['user'] = sess_user();

        $params['id_rk'] = $this->input->get('id');
        $data['data'] = $this->Main_model->get_rk($params);
        $data['per'] = $this->db->get_where("tbl_perusahaan", ["id_perusahaan" => '1'])->row();

        $this->load->view('cetak/penyelesaian', $data);
    }

    public function hapus() {
        if ($this->input->is_ajax_request()) {
            $id = $this->input->post('id');
            $this->db->set([
                'ttd_py' => NULL,
                'status_py' => NULL,
                'alasan_py' => NULL
            ]);
            $this->db->where('id_rk', $id);
            $this->db->update('tbl_rk');
        }
    }

}
