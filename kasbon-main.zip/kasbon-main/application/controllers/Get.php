<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Get extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        is_logged_in();
    }


    public function get_password()
    {
        $id = $this->input->post('id');
        $pw = $this->input->post('password');

        $this->db->where('id_user', $id);

        $user  =  $this->db->get('user')->row_array();
      
        if(password_verify($pw, $user['password']) == true) {
            echo 0; // Tampilkan pesan
        }else{ // Jika belum ada
            echo 1; // Tampilkan pula pesan
        }
    }
    
    public function get_email()
    {
        $segmen = $this->uri->segment(3);
        $email = $this->input->post('email');
        $email1 = $this->input->post('email1');

        if($segmen == 'edit'){
            $this->db->where('email !=', $email1);
        }else{
            $this->db->where('email', $email);
        }
        $data  =  $this->db->get('user')->row_array();

        if($data['email'] == $email) {
            echo 1; 
        }else{
            echo 0; 
        }
    }

    public function get_data_rk()
    {
        $id = $this->input->post('id', true);
        $this->db->where('id_rk', $id);
        echo json_encode($this->db->get('tbl_rk')->row_array());
    }

    public function get_data_bp()
    {
        $id = $this->input->post('id', true);
        $this->db->where('id_bp', $id);
        echo json_encode($this->db->get('tbl_bp')->row_array());
    }
    
    public function get_data_divisi()
    {
        $id = $this->input->post('id', true);
        $this->db->where('id_divisi', $id);
        echo json_encode($this->db->get('tbl_divisi')->row_array());
    }
    
    public function set_flashdata() {
        // Tangkap data yang dikirimkan dari AJAX
        $message = $this->input->post('message');
    
        // Set flashdata
        $this->session->set_flashdata('message', '<div class="alert alert-success alert-dismissible fade show" role="alert">
        '.$message.'
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">&times;</span></button></div>');
    
        // Keluar dari controller
        exit();
    }

    public function convert_to_terbilang() {
        $number = $this->input->post('number');
        echo terbilang($number);
    }
    
}
