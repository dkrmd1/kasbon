<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Bukti_penerimaan extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
           // Periksa apakah sesi login aktif
           is_logged_in();
           $this->load->model('Main_model');
    }

    public function index()
    {
        $data['title'] = "Bukti Penerimaan";
        $data['user'] = sess_user();

        $data['data_user'] = $this->db->get_where('user', [
            'role_id !=' => '5',
            'divisi_id' => $data['user']['divisi_id']
            ])->result();

        $this->load->view('template/header_tabel', $data);
        $this->load->view('template/navbar', $data);
        $this->load->view('dashboard/bukti_penerimaan', $data);
        $this->load->view('template/footer_kasbon');
    }
    

    public function data()
    {
        $data['title'] = "Data Bukti Penerimaan";
        $data['user'] = sess_user();

        $params = [];
        if($data['user']['role_id'] == '2' || $data['user']['role_id'] == '3' || $data['user']['role_id'] == '4'){
            if($data['user']['divisi_id'] !== '1'){
                $params['divisi_id'] = $data['user']['divisi_id'];
            }
        }
        if($data['user']['role_id'] == '5'){
            $params['id_user'] = $data['user']['id_user'];
        }
        $data['data'] = $this->Main_model->get_bp($params);

        $this->load->view('template/header_tabel', $data);
        $this->load->view('template/navbar', $data);
        $this->load->view('dashboard/data/bukti_penerimaan', $data);
        $this->load->view('template/footer_tabel');
    }
    
    public function save()
    {
        $user = sess_user();
        $data = [
            'id_user' => $user['id_user'],
            'divisi_id' => $user['divisi_id'],
            'tgl_bp' => date('Y-m-d'),
            'nama' => $this->input->post('nama'),
            'jabatan' => $this->input->post('jabatan'),
            'uang_muka' => $this->input->post('uang_muka'),
            'terbilang' => $this->input->post('terbilang'),
            'kegiatan' => $this->input->post('kegiatan'),
            'tempat' => $this->input->post('tempat'),
            'waktu' => $this->input->post('waktu'),
            'ttd' => $this->input->post('penandatangan'),
            'note' => $this->input->post('note'),
            'status' => 'Pending',
        ];
        $this->db->insert('tbl_bp', $data);

        $this->session->set_flashdata('message', '<div class="alert alert-success alert-dismissible fade show" role="alert">
        <strong>Success!</strong> Berhasil menambahkan data!
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">&times;</span></button></div>');
        redirect('bukti_penerimaan/data');
    }

    public function update()
    {
        $data['title'] = "Edit Bukti Penerimaan";
        $data['user'] = sess_user();

        
        $data['data_user'] = $this->db->get_where('user', [
            'role_id !=' => '5',
            'divisi_id' => $data['user']['divisi_id']
            ])->result();
            
        $params['id_bp'] = $this->input->get('id');
        $data['data'] = $this->Main_model->get_bp($params);
        if(!$data['data']){
            redirect('bukti_penerimaan/data');
        }

        $this->form_validation->set_rules('nama', 'Nama Lengkap', 'required');
        if ($this->form_validation->run() == false) {
            $this->load->view('template/header_tabel', $data);
            $this->load->view('template/navbar', $data);
            $this->load->view('dashboard/edit/bukti_penerimaan', $data);
            $this->load->view('template/footer_kasbon');
        }else{
            $id = $this->input->post('id_bp');
            $data = [
                'nama' => $this->input->post('nama'),
                'jabatan' => $this->input->post('jabatan'),
                'uang_muka' => $this->input->post('uang_muka'),
                'terbilang' => $this->input->post('terbilang'),
                'kegiatan' => $this->input->post('kegiatan'),
                'tempat' => $this->input->post('tempat'),
                'waktu' => $this->input->post('waktu'),
                'ttd' => $this->input->post('penandatangan'),
                'note' => $this->input->post('note'),
            ];
            $this->db->where('id_bp', $id);
            $this->db->update('tbl_bp', $data);

            $this->session->set_flashdata('message', '<div class="alert alert-success alert-dismissible fade show" role="alert">
            <strong>Success!</strong> Berhasil mengupdate data!
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span></button></div>');
            redirect('bukti_penerimaan/update?id='.$id);
        }
    }


    public function edit_alasan() {
        $id = $this->input->post('id');
        $this->db->set([
            'alasan' => $this->input->post('alasan')
        ]);
        $this->db->where('id_bp', $id);
        $this->db->update('tbl_bp');
        
        $this->session->set_flashdata('message', '<div class="alert alert-success alert-dismissible fade show" role="alert">
        <strong>Success!</strong> Alasan penolakan berhaasil diupdate!
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">&times;</span></button></div>');
        redirect('bukti_penerimaan/data');
    }

    public function approve() {
        $user = sess_user();
        if ($this->input->is_ajax_request()) {
            $id = $this->input->post('id');
            $this->db->set([
                'ttd' => $user['id_user'],
                'alasan' => NULL,
                'status' => 'Approve', 
                'tgl_persetujuan' => date('Y-m-d')
            ]);
            $this->db->where('id_bp', $id);
            $this->db->update('tbl_bp');
        }
    }

    public function ditolak() {
        $id = $this->input->post('id');
        $this->db->set([
            'alasan' => $this->input->post('alasan'),
            'status' => 'Ditolak',
            'tgl_persetujuan' => NULL
        ]);
        $this->db->where('id_bp', $id);
        $this->db->update('tbl_bp');
        
        $this->session->set_flashdata('message', '<div class="alert alert-success alert-dismissible fade show" role="alert">
        <strong>Success!</strong> Penolakan data berhasil!
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">&times;</span></button></div>');
        redirect('bukti_penerimaan/data');
    }

    
    public function cetak()
    {
        $data['title'] = "Cetak Bukti Penerimaan";
        $data['user'] = sess_user();

        $params['id_bp'] = $this->input->get('id');
        $data['data'] = $this->Main_model->get_bp($params);
        $data['per'] = $this->db->get_where("tbl_perusahaan", ["id_perusahaan" => '1'])->row();

        $this->load->view('cetak/bukti_penerimaan', $data);
    }
    
    public function hapus() {
        if ($this->input->is_ajax_request()) {
            $id = $this->input->post('id');
            $this->db->where('id_rk', $id);
            $this->db->delete('tbl_rk');
        }
    }

}
