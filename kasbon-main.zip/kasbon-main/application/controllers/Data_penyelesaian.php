<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Data_penyelesaian extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
           // Periksa apakah sesi login aktif
           is_logged_in();
           $this->load->model('Main_model');
    }
    
    public function index()
    {
        $data['title'] = "Pengajuan Penyelesaian";
        $data['user'] = sess_user();

        $params = [];
        if($data['user']['role_id'] == '2' || $data['user']['role_id'] == '3' || $data['user']['role_id'] == '4'){
            $params['divisi_id'] = $data['user']['divisi_id'];
        }
        if($data['user']['role_id'] == '5'){
            $params['id_user'] = $data['user']['id_user'];
        }
        $params['status'] = 'Approve';
        $this->db->order_by('tbl_rk.id_rk', 'desc');
        $data['data'] = $this->Main_model->get_rk($params);

        $this->load->view('template/header_tabel', $data);
        $this->load->view('template/navbar', $data);
        $this->load->view('dashboard/data_penyelesaian', $data);
        $this->load->view('template/footer_tabel');
    }

    
    public function penyelesaian()
    {
        $data['title'] = "Penyelesaian";
        $data['user'] = sess_user();

        
        $params['id_rk'] = $this->input->get('id');
        $data['data'] = $this->Main_model->get_rk($params);
        if(!$data['data']){
            redirect('data_penyelesaian');
        }

        $data['data_user'] = $this->db->get_where('user', [
            'role_id !=' => '5',
            'divisi_id' => $data['user']['divisi_id']
            ])->result();

        $this->load->view('template/header_tabel', $data);
        $this->load->view('template/navbar', $data);
        $this->load->view('dashboard/penyelesaian', $data);
        $this->load->view('template/footer_kasbon');
    }

    
    public function save()
    {
        $id = $this->input->post('id_rk');
        $data = [
            'rincian' => $this->input->post('rincian'),
            'ttd_py' => $this->input->post('ttd_py'),
            'status_py' => 'Pending',
        ];
        $this->db->where('id_rk', $id);
        $this->db->update('tbl_rk', $data);

        $this->session->set_flashdata('message', '<div class="alert alert-success alert-dismissible fade show" role="alert">
        <strong>Success!</strong> Berhasil mengajukan data!
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">&times;</span></button></div>');
        redirect('data_penyelesaian');
    }

    public function update()
    {
        $data['title'] = "Edit Penyelesaian";
        $data['user'] = sess_user();

        $params['id_rk'] = $this->input->get('id');
        $data['data'] = $this->Main_model->get_rk($params);

        $data['data_user'] = $this->db->get_where('user', [
            'role_id !=' => '5',
            'divisi_id' => $data['user']['divisi_id']
            ])->result();
            
        if(!$data['data']){
            redirect('penyelesaian/data');
        }

        $this->form_validation->set_rules('ttd_py', 'Penandatangan', 'required');
        if ($this->form_validation->run() == false) {
            $this->load->view('template/header_tabel', $data);
            $this->load->view('template/navbar', $data);
            $this->load->view('dashboard/edit/penyelesaian', $data);
            $this->load->view('template/footer_kasbon');
        }else{
            $id = $this->input->post('id_rk');
            $this->db->set([
                'rincian' => $this->input->post('rincian'),
                'ttd_py' => $this->input->post('ttd_py')
            ]);
            $this->db->where('id_rk', $id);
            $this->db->update('tbl_rk');

            $this->session->set_flashdata('message', '<div class="alert alert-success alert-dismissible fade show" role="alert">
            <strong>Success!</strong> Berhasil mengupdate data!
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span></button></div>');
            redirect('data_penyelesaian/update?id='.$id);
        }
    }
    
}
