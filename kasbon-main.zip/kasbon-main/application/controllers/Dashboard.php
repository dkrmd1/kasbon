<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Dashboard extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        is_logged_in();
        $this->load->model('Main_model');
    }

    public function index()
    {
        $data['title'] = "Dashboard";
        $data['user'] = sess_user();
        $user = sess_user();
        $data['pegawai'] = $this->db->get_where("user", ["role_id !=" => '1'])->num_rows();

        $data['sk'] = $this->db->get_where("tbl_rk", ['divisi_id' => $user['divisi_id']])->num_rows();

        $data['sk_approve'] = $this->db->get_where("tbl_rk", ['divisi_id' => $user['divisi_id'], 'status' => 'Approve'])->num_rows();
        $data['sk_pending'] = $this->db->get_where("tbl_rk", ['divisi_id' => $user['divisi_id'], 'status' => 'Pending'])->num_rows();

        if($user['role_id'] == '5'){
            $params['id_user'] = $user['id_user'];
        }
        $params['divisi_id'] = $user['divisi_id'];
        
        $this->db->where('tbl_rk.status', 'Pending')->order_by('id_rk', 'DESC')->limit(5);
        $data['rk_list'] = $this->Main_model->get_rk($params);

        $this->load->view('template/header', $data);
        $this->load->view('template/navbar', $data);
        $this->load->view('dashboard/index', $data);
        $this->load->view('template/footer_kasbon');
    }
    
}
