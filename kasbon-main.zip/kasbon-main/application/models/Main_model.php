<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Main_model extends CI_Model
{
    // Fetch siswa
    function get_user($params = array())
    {
        if (isset($params['role'])) {
            if ($params['role'] == 'pegawai') {
                $this->db->where('role_id', 2);
            } elseif ($params['role'] == 'staff') {
                $this->db->where('role_id', 3);
            }
        }
        $this->db->select('user.*, user.name as nama_user, tbl_divisi.divisi as nama_divisi');
        $this->db->join('tbl_divisi', 'tbl_divisi.id_divisi = user.divisi_id', 'left');
        $res = $this->db->get('user');
        if (isset($params['id_user'])) {
            return $res->row();
        } else {
            return $res->result();
        }
    }
    
    function get_rk($params = array())
    {
        if (isset($params['id_rk'])) {
            $this->db->where('tbl_rk.id_rk', $params['id_rk']);
        }
        if (isset($params['divisi_id'])) {
            $this->db->where('tbl_rk.divisi_id', $params['divisi_id']);
        }
        if (isset($params['id_user'])) {
            $this->db->where('tbl_rk.id_user', $params['id_user']);
        }
        if (isset($params['status'])) {
            // If status is an array, use `where_in` for multiple values
            if (is_array($params['status'])) {
                $this->db->where_in('tbl_rk.status', $params['status']);
            } else {
                $this->db->where('tbl_rk.status', $params['status']);
            }
        }
        if (isset($params['approval'])) {
            $this->db->where('tbl_rk.approval', $params['approval']);
        }
        if (isset($params['not_status'])) {
            $this->db->where('tbl_rk.status !=', $params['not_status']);
        }
        if (isset($params['status_fin'])) {
            if (is_array($params['status_fin'])) {
                $this->db->where_in('tbl_rk.status_fin', $params['status_fin']);
            } else {
                $this->db->where('tbl_rk.status_fin', $params['status_fin']);
            }
        }
        if (isset($params['status_py'])) {
            if (is_array($params['status_py'])) {
                $this->db->where_in('tbl_rk.status_py', $params['status_py']);
            } else {
                $this->db->where('tbl_rk.status_py', $params['status_py']);
            }
        }
    
        $this->db->select('tbl_rk.*, user.name as nama_user, user.jabatan as jabatan_user, tbl_divisi.divisi as divisi, uttd.name as nama_penandatangan, uttd.jabatan as ttd_jabatan, uttd.ttd as ttd_penandatangan');
        $this->db->join('user', 'user.id_user = tbl_rk.id_user', 'left');
        $this->db->join('user as uttd', 'uttd.id_user = tbl_rk.ttd', 'left');
        $this->db->join('tbl_divisi', 'tbl_divisi.id_divisi = tbl_rk.divisi_id', 'left');
        $res = $this->db->get('tbl_rk');
    
        if (isset($params['id_rk'])) {
            return $res->row(); // Return a single row if `id_rk` is set
        } else {
            return $res->result(); // Return multiple rows otherwise
        }
    }
    

    function get_bp($params = array())
    {
        if (isset($params['id_bp'])) {
            $this->db->where('tbl_bp.id_bp', $params['id_bp']);
        }
        if (isset($params['divisi_id'])) {
            $this->db->where('tbl_bp.divisi_id', $params['divisi_id']);
        }
        if (isset($params['id_user'])) {
            $this->db->where('tbl_bp.id_user', $params['id_user']);
        }
        if (isset($params['status'])) {
            $this->db->where('tbl_bp.status', $params['status']);
        }
        if (isset($params['not_status'])) {
            $this->db->where('tbl_bp.status !=', $params['not_status']);
        }
        $this->db->select('tbl_bp.*, user.name as nama_user, user.jabatan as jabatan_user, uttd.name as nama_penandatangan, uttd.jabatan as ttd_jabatan, uttd.ttd as ttd_penandatangan');
        $this->db->join('user', 'user.id_user = tbl_bp.id_user', 'left');
        $this->db->join('user as uttd', 'uttd.id_user = tbl_bp.ttd', 'left');
        $res = $this->db->get('tbl_bp');
        if (isset($params['id_bp'])) {
            return $res->row();
        } else {
            return $res->result();
        }
    }

    function get_py($params = array())
    {
        if (isset($params['id_py'])) {
            $this->db->where('tbl_penyelesaian.id_py', $params['id_py']);
        }
        if (isset($params['divisi_id'])) {
            $this->db->where('tbl_penyelesaian.divisi_id', $params['divisi_id']);
        }
        if (isset($params['id_user'])) {
            $this->db->where('tbl_penyelesaian.id_user', $params['id_user']);
        }
        if (isset($params['status'])) {
            $this->db->where('tbl_penyelesaian.status', $params['status']);
        }
        if (isset($params['not_status'])) {
            $this->db->where('tbl_penyelesaian.status !=', $params['not_status']);
        }
        $this->db->select('tbl_penyelesaian.*, user.name as nama_user, user.jabatan as jabatan_user, uttd.name as nama_penandatangan, uttd.jabatan as ttd_jabatan, uttd.ttd as ttd_penandatangan');
        $this->db->join('user', 'user.id_user = tbl_penyelesaian.id_user', 'left');
        $this->db->join('user as uttd', 'uttd.id_user = tbl_penyelesaian.ttd', 'left');
        $res = $this->db->get('tbl_penyelesaian');
        if (isset($params['id_py'])) {
            return $res->row();
        } else {
            return $res->result();
        }
    }
}