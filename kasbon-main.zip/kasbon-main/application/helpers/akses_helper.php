<?php

if (!function_exists('is_logged_in')) {
    function is_logged_in()
    {
        $ci = get_instance();
        
        $email = $ci->session->userdata('email');
        $role_id = $ci->session->userdata('role_id');

        $ci->db->where('email', $email);
        $ci->db->where('role_id', $role_id);
        $user = $ci->db->get('user')->row();

        if ($user) {
            if ($email !== $user->email || $role_id !== $user->role_id) {
                $ci->session->unset_userdata('email');
                $ci->session->unset_userdata('role_id');
                delete_cookie('remember_me');

                $ci->session->set_flashdata('message', '<div class="alert alert-danger alert-dismissible fade show" role="alert">
                Silahkan login terlebih dahulu!
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
                </button></div>');
                redirect('auth');
            }
        } else {
            $ci->session->unset_userdata('email');
            $ci->session->unset_userdata('role_id');
            delete_cookie('remember_me');

            $ci->session->set_flashdata('message', '<div class="alert alert-danger alert-dismissible fade show" role="alert">
            Silahkan login terlebih dahulu!
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span></button></div>');
            redirect('auth');
        }
    }
}


if (!function_exists('sess_user')) {
    function sess_user()
    {
        $ci = get_instance();
        $array = $ci->db->get_where('user', ['email' => $ci->session->userdata('email')]);
        return $array->row_array();
    }
}