<?php

if (!function_exists('notif')) {
    function notif()
    {
        $ci = get_instance();
        $user = $ci->db->get_where('user', ['email' => $ci->session->userdata('email')])->row();
                            
        if($user->divisi_id == '1'){
            $rkn = $ci->db->get_where('tbl_rk', ['status' => 'Pending', 'approval' => 'GH'])->num_rows();
        }else{
            $rkn = $ci->db->get_where('tbl_rk', ['status' => 'Pending', 'approval' => 'Pending'])->num_rows();
        }
        $py = $ci->db->get_where('tbl_rk', ['status_py' => 'Pending'])->num_rows();

        $all = $rkn + $py;

        return (object) [
            'notif_rk'  => $rkn,
            'notif_py'  => $py,
            'notif_all' => $all,
        ];
    }
}