<?php
function terbilang($x) {
    $angka = ["", "satu", "dua", "tiga", "empat", "lima", "enam", "tujuh", "delapan", "sembilan", "sepuluh", "sebelas"];
    
    // Menangani kasus angka dari 0 hingga 11
    if ($x < 12) {
        return ucfirst($angka[$x]) . " rupiah";
    }
    
    // Menangani angka dari 12 hingga 19
    elseif ($x < 20) {
        return ucfirst(terbilang($x - 10)) . " belas rupiah";
    }
    
    // Menangani angka dari 20 hingga 99
    elseif ($x < 100) {
        $tens = floor($x / 10);
        $units = $x % 10;
        $result = trim(terbilang($tens) . " puluh" . ($units ? " " . terbilang($units) : ""));
        return ucfirst($result) . " rupiah";
    }
    
    // Menangani angka dari 100 hingga 199
    elseif ($x < 200) {
        $result = "seratus" . ($x > 100 ? " " . terbilang($x - 100) : "");
        return ucfirst($result) . " rupiah";
    }
    
    // Menangani angka dari 200 hingga 999
    elseif ($x < 1000) {
        $hundreds = floor($x / 100);
        $remainder = $x % 100;
        $result = trim(terbilang($hundreds) . " ratus" . ($remainder ? " " . terbilang($remainder) : ""));
        return ucfirst($result) . " rupiah";
    }
    
    // Menangani angka dari 1000 hingga 1999
    elseif ($x < 2000) {
        $result = "seribu" . ($x > 1000 ? " " . terbilang($x - 1000) : "");
        return ucfirst($result) . " rupiah";
    }
    
    // Menangani angka dari 2000 hingga 999999
    elseif ($x < 1000000) {
        $thousands = floor($x / 1000);
        $remainder = $x % 1000;
        $result = trim(terbilang($thousands) . " ribu" . ($remainder ? " " . terbilang($remainder) : ""));
        return ucfirst($result) . " rupiah";
    }
    
    // Menangani angka dari 1000000 hingga 1999999
    elseif ($x < 1000000000) {
        $millions = floor($x / 1000000);
        $remainder = $x % 1000000;
        $result = trim(terbilang($millions) . " juta" . ($remainder ? " " . terbilang($remainder) : ""));
        return ucfirst($result) . " rupiah";
    }
    
    // Menangani angka 1000000000 dan seterusnya
    else {
        $billions = floor($x / 1000000000);
        $remainder = $x % 1000000000;
        $result = trim(terbilang($billions) . " milyar" . ($remainder ? " " . terbilang($remainder) : ""));
        return ucfirst($result) . " rupiah";
    }
}
